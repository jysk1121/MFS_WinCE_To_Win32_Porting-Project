#pragma once

#include <Windows.h>
//#include <String.h>
#include <dshow.h>
//#include <initguid.h>
//#include "NvMediaSample.h"

BOOL writeTextOnBitmap(DWORD x, DWORD y, LPCTSTR stringToDisplay, DWORD fontHeight, DWORD fontWidht, BOOL eraseScreen, COLORREF color);
BOOL createBitmap(DWORD widht, DWORD height);
DWORD loadUserBitmap(BYTE **y, BYTE **u, BYTE **v);
BOOL convertRGB24toYUV420(DWORD widht, DWORD height, WORD *bitmapDone);

DEFINE_GUID(CLSID_SampleGrabber, 
0xad5db5b4, 0xd1ab, 0x4f37, 0xa6, 0xd, 0x21, 0x51, 0x54, 0xb4, 0xec, 0xc1);
// {01B86B76-922C-4192-A6CD-64CFF39775CF}
DEFINE_GUID(MEDIASUBTYPE_NvYUV420, 
0x1b86b76, 0x922c, 0x4192, 0xa6, 0xcd, 0x64, 0xcf, 0xf3, 0x97, 0x75, 0xcf);

// 30323449-0000-0010-8000-00AA00389B71  'I420' ==  MEDIASUBTYPE_I420
DEFINE_GUID(MEDIASUBTYPE_NvI420,
0x30323449, 0x0000, 0x0010, 0x80, 0x00, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71);

/// {28e3a27d-5f48-4700-913b-4986608c8a8b}
DEFINE_GUID(MEDIATYPE_NvVideoBuffered,
0x28e3a27d, 0x5f48, 0x4700, 0x91, 0x3b, 0x49, 0x86, 0x60, 0x8c, 0x8a, 0x8b);

DEFINE_GUID(MEDIASUBTYPE_Bayer,
0xed58f0cb, 0x9f4d, 0x4ace, 0xb0, 0xa5, 0xa9, 0xe8, 0x48, 0x85, 0xb0, 0xa7);

/// {2D316723-50DB-437D-865E-C2FD3B5B018D}
DEFINE_GUID(MEDIASUBTYPE_NvMMBuffer,
0x2d316723, 0x50db, 0x437d, 0x86, 0x5e, 0xc2, 0xfd, 0x3b, 0x5b, 0x1, 0x8d);

DEFINE_GUID(MEDIATYPE_NvVideo,
0x2cfc3df4, 0xcd5a, 0x4a8f, 0xbf, 0xae, 0x91, 0xd6, 0xb0, 0x86, 0xeb, 0x90);


// ISampleGrabber interface definition 
#ifdef __cplusplus 
extern "C" { 
#endif 
DEFINE_GUID(IID_ISampleGrabber,	0x4951bff, 0x696a, 0x4ade, 0x82, 0x8d, 0x42, 0xa5, 0xf1, 0xed, 0xb6, 0x31);
#define FILTERNAME L"SampleGrabberFilter"
// callback definition
typedef void (CALLBACK *MANAGED_SAMPLEPROCESSEDPROC)(BYTE* pdata, long len, long m_Height, long m_Width, long m_Stride);

DECLARE_INTERFACE_(ISampleGrabber, IUnknown)
{
    STDMETHOD(RegisterCallback)(MANAGED_SAMPLEPROCESSEDPROC callback) PURE;
};
#ifdef __cplusplus 
} 
#endif

// Media types
const AMOVIESETUP_MEDIATYPE sudPinTypes [] =
	{
		{&MEDIATYPE_Video,&MEDIASUBTYPE_RGB565},
		{&MEDIATYPE_Video,&MEDIASUBTYPE_YUY2},
	};

// Pins
const AMOVIESETUP_PIN sudpPins[] =
	{
		{
		L"VideoInput",					// Pin string name
			FALSE,                      // Is it rendered
			FALSE,                      // Is it an output
			FALSE,                      // Allowed none
			FALSE,                      // Likewise many
			&CLSID_NULL,                // Connects to filter
			NULL,                       // Connects to pin
			2,                          // Number of types
			sudPinTypes                 // Pin information
		},
		{
		L"VideoOutput",					// Pin string name
			FALSE,                      // Is it rendered
			FALSE,                      // Is it an output
			FALSE,                      // Allowed none
			FALSE,                      // Likewise many
			&CLSID_NULL,                // Connects to filter
			NULL,                       // Connects to pin
			2,                          // Number of types
			sudPinTypes                 // Pin information
			}
	};

// Filters
const AMOVIESETUP_FILTER sudSampleGrabber =
	{
	&CLSID_SampleGrabber,				// Filter CLSID
	FILTERNAME,							// String name
	MERIT_NORMAL,						//MERIT_DO_NOT_USE,			// Filter merit
	2,									// Number of pins
	sudpPins							// Pin information
	};

class CSampleGrabber :public CTransInPlaceFilter, public ISampleGrabber
	{
	private:
		VIDEOINFOHEADER m_videoInfo;
		MANAGED_SAMPLEPROCESSEDPROC callback;
		long m_Width;
		long m_Height;
		long m_SampleSize;
		long m_Stride;
	public:
		// instantiation
		CSampleGrabber( IUnknown * pOuter, HRESULT * phr, BOOL ModifiesData );
		~CSampleGrabber();
		static CUnknown *WINAPI CreateInstance(LPUNKNOWN punk, HRESULT *phr);

		// IUnknown
		DECLARE_IUNKNOWN;
		STDMETHODIMP NonDelegatingQueryInterface(REFIID riid, void ** ppv);
		
		// CTransInPlaceFilter
		DWORD GetPitch(DWORD width, DWORD alignment);
		HRESULT CheckInputType(const CMediaType *pmt);
		HRESULT Transform(IMediaSample *pMediaSample);
		STDMETHODIMP RegisterCallback(MANAGED_SAMPLEPROCESSEDPROC mdelegate);
		void PrintMediaInfo(const CMediaType *pmt);
		HRESULT SetMediaType(PIN_DIRECTION direction, const CMediaType *pmt);
		HRESULT DecideBufferSize(IMemAllocator *pAlloc, ALLOCATOR_PROPERTIES *pProperties);
		HRESULT GetMediaType(int iPosition, CMediaType *pMediaType);

		STDMETHODIMP_(ULONG) NonDelegatingAddRef()
		{
		return InterlockedIncrement(&m_cRef);
		}


		//-----------------------------------------------------------------------------
		// Decrement the reference count for an interface
		// ////////////////////////////////////////
		STDMETHODIMP_(ULONG) NonDelegatingRelease()
		{
			if(InterlockedDecrement(&m_cRef) == 0)
			{
			delete this;
			return 0;
			}
			return m_cRef;
		}
		//HRESULT Receive(IMediaSample *pSample);
	};
