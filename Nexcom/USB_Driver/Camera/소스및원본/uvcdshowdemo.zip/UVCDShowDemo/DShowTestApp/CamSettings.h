#ifndef _CAM_SETTINGS_
#define _CAM_SETTINGS_

#define MAXFORMATS  30

typedef struct _CAMFORMATPROS
{
	int index;
	LONG width;
	LONG height;
	LONGLONG AvgTimePerFrame;
	GUID subType;
}CAMFORMATPROS,*PCAMFORMATPROS;


LRESULT CALLBACK WhiteBalanceDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK EffectsDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK ZoomDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK BrightnessDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK  ResolutionSelectDlgProc(HWND hDlg, unsigned message, LONG wParam, LONG lParam);
LRESULT CALLBACK FlashDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK ManualFocusDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK ContrastDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK HueDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK SaturationDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK SharpnessDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK GammaDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK ExposureDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK BacklightDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
//HRESULT GetSupportedResolution(int nStream,struct supported_resolutions *supResolutions);
HRESULT GetCurrentVideoResolution();
HRESULT GetCurrentStillResolution();
HRESULT GetVideoProfile(int nStream,UINT8 nCurrentRes,UINT8 nIndexType);

#endif 