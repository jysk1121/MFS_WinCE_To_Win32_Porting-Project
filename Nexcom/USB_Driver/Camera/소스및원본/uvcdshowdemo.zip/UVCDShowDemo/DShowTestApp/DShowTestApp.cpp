// DShowTestApp.cpp : Defines the entry point for the application.
//

//#include "stdafx.h"
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#include <windows.h> 
#include "DShowTestApp.h"
#include "CamSettings.h"
#include "captureframework.h"
#include <commctrl.h>
#include "enumdef.h"



#define MAX_LOADSTRING 100

// Global Variables:
BOOL g_bCameraSelected = FALSE;
static HINSTANCE g_hInstance = NULL;
HWND g_Hwnd=NULL;

UINT32  g_NumofCaptureResolutions;
UINT32  g_NumofStillResolutions;
UINT8	g_CaptureResolutionIndex;
UINT8	g_StillResolutionIndex;
UINT32  g_MenuBarHeight;
HWND	g_hwndStillPins;
HWND	g_hwndColorSpace;
HWND	g_hwndCapturePins;
AM_MEDIA_TYPE *g_CurrentVideoProfile;
AM_MEDIA_TYPE *g_CurrentStillProfile;

//short int userReq ;
//short int nPos;
//HANDLE hwndScrollBar;

INT32 PropMin;
INT32 PropMax;
INT32 PropDefault;
INT32 PropStepping;
INT32 PropFlag;
INT32 PropValue;
BOOL nChecked;
UINT32 PropNum;

typedef struct _CAMERA_PROP
{
	UINT8  VideoProper;
	INT16  Value;
	INT16  Default;
	HWND   hSlid;
	HWND   hEditValue;
	BOOL   bAuto;
	const int    IDCSlid;
	const int    IDCEditValue;
	const int    IDCCheck;
	BOOL   bSupport;
	BOOL   bAutoSupport;
}CAMERAPROP;

#define  NUMBER_OF_PROP  8


CAMERAPROP CameraVideoProperties[] = 
{	
	{VideoProcAmp_Brightness,FALSE,FALSE,NULL,NULL,FALSE,IDC_BRIGHTNESS,IDC_BRIGHTVALUE,IDC_BRIGHTNESSCHECK,TRUE,FALSE},
	{VideoProcAmp_Contrast,FALSE,FALSE,NULL,NULL,FALSE,IDC_CONTRAST,IDC_CONTRASTVALUE,IDC_CONTRASTCHECK,TRUE,FALSE},
	{VideoProcAmp_Hue,FALSE, FALSE,NULL,NULL,FALSE,IDC_HUE,IDC_HUEVALUE,IDC_HUECHECK,TRUE,FALSE},
	{VideoProcAmp_Saturation,FALSE,FALSE,NULL,NULL,FALSE,IDC_SATURATION,IDC_SATURATIONVALUE,IDC_SATURATIONCHECK,TRUE,FALSE},
	{VideoProcAmp_Sharpness,FALSE,FALSE,NULL,NULL,FALSE,IDC_SHARPNESS,IDC_SHARPNESSVALUE,IDC_SHARPNESSCHECK,TRUE,FALSE},
	{VideoProcAmp_Gamma,FALSE,FALSE,NULL,NULL,FALSE,IDC_Gamma,IDC_GAMMAVALUE,IDC_GAMMACHECK,TRUE,FALSE},
	{VideoProcAmp_WhiteBalance,FALSE,FALSE,NULL,NULL,FALSE,IDC_WHITEBALANCE,IDC_WHITEBALANCEVALUE,IDC_WHITEBALANCECHECK,TRUE,FALSE},
	{VideoProcAmp_BacklightCompensation,FALSE,FALSE,NULL,NULL,FALSE,IDC_BACKLIGHT,IDC_BACKLIGHTVALUE,IDC_BACKLIGHTCHECK,TRUE,FALSE},
};

CAMERAPROP CameraControlProperties[] = 
{	
	{CameraControl_Pan,FALSE,FALSE,NULL,NULL,FALSE,IDC_PAN,IDC_PANVALUE,IDC_PANCHECK,TRUE,FALSE},
	{CameraControl_Tilt,FALSE,FALSE,NULL,NULL,FALSE,IDC_TILT,IDC_TILTVALUE,IDC_TILTCHECK,TRUE,FALSE},
	{CameraControl_Roll,FALSE, FALSE,NULL,NULL,FALSE,IDC_ROLL,IDC_ROLLVALUE,IDC_ROLLCHECK,TRUE,FALSE},
	{CameraControl_Zoom,FALSE,FALSE,NULL,NULL,FALSE,IDC_ZOOM,IDC_ZOOMVALUE,IDC_ZOOMCHECK,TRUE,FALSE},
	{CameraControl_Iris,FALSE,FALSE,NULL,NULL,FALSE,IDC_IRIS,IDC_IRISVALUE,IDC_IRISCHECK,TRUE,FALSE},
	{CameraControl_Exposure,FALSE,FALSE,NULL,NULL,FALSE,IDC_EXPOSURE,IDC_EXPOSUREVALUE,IDC_EXPOSURECHECK1,TRUE,FALSE},
	{CameraControl_Focus,FALSE,FALSE,NULL,NULL,FALSE,IDC_FOCUS,IDC_FOCUSVALUE,IDC_FOCUSCHECK,TRUE,FALSE},
	{CameraControl_Flash,FALSE,FALSE,NULL,NULL,FALSE,IDC_FLASH,IDC_FLASHVALUE,IDC_FLASHCHECK,TRUE,FALSE},
};

CCaptureFramework g_DShowCaptureGraph;
DWORD g_dwFilters = 0;
BOOL gAudioCapture=FALSE;
BOOL gAudioEncoder=FALSE;
TCHAR g_tszStillFileName[MAX_PATH] = STILL_IMAGE_FILE_NAME;
TCHAR g_tszCaptureFileName[MAX_PATH] = VIDEO_CAPTURE_FILE_NAME;

BOOL g_bVideoRecord = FALSE;
BOOL g_bCapturePaused = FALSE;
int g_nFramesProcessed = 0;
int g_nOOMEvents = 0;
RECT g_rcStatusArea = {0, 0, 0, 0};
REFERENCE_TIME g_rtCaptureStart;
REFERENCE_TIME g_rtCurrentEncodePosition;
REFERENCE_TIME g_rtEndEncodePosition;
HWND g_hwndEncodeStatus = NULL;
HWND g_hwndDroppedFrames = NULL;
UINT g_uiLastEncodePosition = 100;
UINT g_uiLastDroppedFramesPosition = 0;

// Forward declarations of functions included in this code module:
ATOM			MyRegisterClass(HINSTANCE, LPTSTR);
BOOL			InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
HRESULT ChangeCurrentResolution(int nStream,UINT8 nCurrentRes);
INT_PTR CALLBACK CameraProDialogProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam);
HRESULT CameraVideoPropAutoUpdate(HWND hDlg,int VideoProp,int AutoChecked);
HRESULT CameraControlPropAutoUpdate(HWND hDlg,int VideoProp,int AutoChecked);
INT_PTR CALLBACK CameraControlProDialogProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam);
INT_PTR CALLBACK FormatSelectDialog(HWND hDlg, unsigned message, LONG wParam, LONG lParam);
INT_PTR CALLBACK CapturePinDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
HRESULT GetResolution(int nStream,CAMFORMATPROS *supResolutions,UINT8 index);

#define AF_UVC_CAMERA_FIX 0

void Debug(LPCTSTR szFormat, ...)
{
    static  TCHAR   szHeader[] = TEXT("");
    TCHAR   szBuffer[1024];

    va_list pArgs;
    va_start(pArgs, szFormat);
    lstrcpy(szBuffer, szHeader);
    _vstprintf(
        szBuffer + countof(szHeader) - 1,
        szFormat,
        pArgs);
    va_end(pArgs);

    _tcscat(szBuffer, TEXT("\r\n"));

    OutputDebugString(szBuffer);
}

//
//  FUNCTION: ProcessEvents
//
//  PURPOSE: Process Events
//
//  COMMENTS:
//
HRESULT
ProcessEvents(BOOL bComplete, BOOL bWaitForVideo, WORD wVideoCookie, BOOL bWaitForAudio, WORD wAudioCookie )
{
    LONG lEvent, lParam1, lParam2;
    HRESULT hrEvent;
    long lEventTimeout = bComplete?60000:0;
    UINT uiNewEncodePosition, uiNewDroppedFramesPositon;
    // if we're waiting for event 1, then set the received state to false.
    // if we're not waiting for the event, then set the received state to true
    BOOL bReceivedVideoEvent = !bWaitForVideo, bReceivedAudioEvent = !bWaitForAudio;

    while(1)
    {
        hrEvent = g_DShowCaptureGraph.GetEvent(&lEvent, &lParam1, &lParam2, lEventTimeout);
        if(SUCCEEDED(hrEvent))
        {
            // if we succeeded, then see what the event was
            if(lEvent == EC_CAP_SAMPLE_PROCESSED)
            {
                // if the event was a sample processed message, nothing was allocated to be freed in the free,
                // so we're OK accessing lParam1 (not a use after free).
				g_rtCurrentEncodePosition = (REFERENCE_TIME) lParam2 * 10000;
                g_nFramesProcessed++;
            }
            else if(lEvent == EC_BUFFER_FULL)
            {
                g_nOOMEvents++;
                // processing frames is already outputted by GetMediaEvent.
				if((g_nOOMEvents % 20) == 0)
                    Log(TEXT("Frames dropped"));
            }
            else if(lEvent == EC_BUFFER_DOWNSTREAM_ERROR)
            {
				Log(TEXT("Buffering filter failed to deliver data downstream."));
            }
            else if(lEvent == EC_STREAM_CONTROL_STOPPED && lParam2 == wVideoCookie)
                bReceivedVideoEvent = TRUE;
            else if(lEvent == EC_STREAM_CONTROL_STOPPED && lParam2 == wAudioCookie)
                bReceivedAudioEvent = TRUE;

            uiNewEncodePosition = (UINT) (((float) (g_rtCurrentEncodePosition - g_rtCaptureStart))/((float) (g_rtEndEncodePosition - g_rtCaptureStart)) * 100.);
            uiNewDroppedFramesPositon = (UINT) (((float) g_nOOMEvents / (float) max((g_nOOMEvents + g_nFramesProcessed), 1)) * 100.);
            SendMessage(g_hwndEncodeStatus, PBM_DELTAPOS, (WPARAM) (uiNewEncodePosition - g_uiLastEncodePosition), 0);
            SendMessage(g_hwndDroppedFrames, PBM_DELTAPOS, (WPARAM) (uiNewDroppedFramesPositon - g_uiLastDroppedFramesPosition), 0);

            g_uiLastEncodePosition = uiNewEncodePosition;
            g_uiLastDroppedFramesPosition = uiNewDroppedFramesPositon;

            if(bComplete && bReceivedVideoEvent && bReceivedAudioEvent)
				return S_OK;

        }
                      
		else 
		{
			return bComplete?E_FAIL:S_FALSE;
		}
    }

	return E_FAIL;
}

//
//  FUNCTION: StopStreamCapture
//
//  PURPOSE: 
//
//  COMMENTS:
//
HRESULT
StopStreamCapture()
{
    HRESULT hr = S_OK;
    REFERENCE_TIME rtStart = 0;
    REFERENCE_TIME rtStop = 0;
    WORD wVideoStartCookie = 5, wVideoStopCookie = 6;
    WORD wAudioStartCookie = 7, wAudioStopCookie = 8;
    CComPtr<IMediaSeeking> pMediaSeeking;
    int nMediaEventsCounted = 0;
    CComPtr<ICaptureGraphBuilder2> pCaptureGraphBuilder = NULL;
    CComPtr<IGraphBuilder> pFilterGraph = NULL;
    CComPtr<IBaseFilter> pVideoCaptureFilter = NULL;
    CComPtr<IBaseFilter> pAudioCaptureFilter = NULL;

    if (FAILED(g_DShowCaptureGraph.GetBuilderInterface((void**)&pCaptureGraphBuilder, IID_ICaptureGraphBuilder2)))
    {
        RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to retrieve the capture graph builder.")));
        goto cleanup;
    }

    if (FAILED(g_DShowCaptureGraph.GetBuilderInterface((void**)&pFilterGraph, IID_IGraphBuilder)))
    {
        RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to retrieve the graph builder.")));
        goto cleanup;
    }

    hr = pFilterGraph->QueryInterface( &pMediaSeeking );
    if(FAILED(hr) || pMediaSeeking == NULL)
    {
        FAIL(TEXT("CCaptureFramework: Retrieving the MediaSeeking interface failed."));
        goto cleanup;
    }

    hr = pMediaSeeking->GetCurrentPosition(&rtStop);
    if(FAILED(hr))
    {
        RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to retrieve the current position.")));
        goto cleanup;
    }

    g_rtEndEncodePosition = rtStop;

    if(g_dwFilters & VIDEO_CAPTURE_FILTER)
    {
        if(FAILED(g_DShowCaptureGraph.GetBaseFilter((void**)&pVideoCaptureFilter, VIDEO_CAPTURE_FILTER)))
        {
            RETAILMSG(1, ( TEXT("CameraDShowApp: Unable to retrieve the video capture filter.")));
            goto cleanup;
        }

        if(g_dwFilters & VIDEO_CAPTURE_FILTER)
        {
            hr = pCaptureGraphBuilder->ControlStream( &PIN_CATEGORY_PREVIEW, &MEDIATYPE_Video, pVideoCaptureFilter, NULL, 0, 0, 0 );
            if(FAILED(hr))
            {
                RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to pause the preview stream.")));
            }
        }

        hr = pCaptureGraphBuilder->ControlStream( &PIN_CATEGORY_CAPTURE, &MEDIATYPE_Video, pVideoCaptureFilter, &rtStart, &rtStop, wVideoStartCookie, wVideoStopCookie);
        if(FAILED(hr))
        {
            RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to stop the video stream.")));
            goto cleanup;
        }
    }

    if(g_dwFilters & AUDIO_CAPTURE_FILTER)
    {
        if(FAILED(g_DShowCaptureGraph.GetBaseFilter((void**)&pAudioCaptureFilter, AUDIO_CAPTURE_FILTER)))
        {
            RETAILMSG(1, ( TEXT("CameraDShowApp: Unable to retrieve the video capture filter.")));
            goto cleanup;
        }

        hr = pCaptureGraphBuilder->ControlStream( &PIN_CATEGORY_CAPTURE, &MEDIATYPE_Audio, pAudioCaptureFilter, &rtStart, &rtStop, wAudioStartCookie, wAudioStopCookie);
        if(FAILED(hr))
        {
            RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to stop the audio stream.")));
            goto cleanup;
        }
    }
    RETAILMSG(1, ( TEXT("stopstreaming\r\n\n\n")));
    if(FAILED(ProcessEvents(TRUE, g_dwFilters & VIDEO_CAPTURE_FILTER, wVideoStopCookie, g_dwFilters & AUDIO_CAPTURE_FILTER, wAudioStopCookie)))
    {
        RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to process events.")));
        goto cleanup;
    }

    Log(TEXT("%d frames processed"), g_nFramesProcessed);

    if(g_dwFilters & VIDEO_CAPTURE_FILTER)
    {
        LONGLONG llEnd = MAXLONGLONG;
        hr = pCaptureGraphBuilder->ControlStream( &PIN_CATEGORY_PREVIEW, &MEDIATYPE_Video, pVideoCaptureFilter, NULL, &llEnd, 0, 0 );
        if(FAILED(hr))
        {
            RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to restart the preview stream.")));
        }
    }

cleanup:
    return hr;
}

//
//  FUNCTION: WndProc
//
//  PURPOSE: 
//
//  COMMENTS:
//
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    RECT rc = {0, 0, 0, 0};
	HRESULT hr = S_OK;
	int wmId, wmEvent;
    PAINTSTRUCT ps;
    HDC hdc;
	HKEY  hKey = 0;
	DWORD dwType  = 0;
	DWORD dwSize  = MAX_PATH*2;
	DWORD deviceFound = FALSE;
	TCHAR deviceName[MAX_PATH];

    switch(msg)
    {
        case WM_CREATE:			
			g_Hwnd = CommandBar_Create(g_hInstance, hwnd, 1);
            CommandBar_InsertMenubar(g_Hwnd, g_hInstance, IDR_MENU, 0);
            CommandBar_AddAdornments(g_Hwnd, 0, 0);
			
			InitCommonControls();
			LPTSTR lpCmdLine;
			memset(&msg, 0, sizeof(MSG));

			g_MenuBarHeight = CommandBar_Height(g_Hwnd);

			TCHAR **ptszCameraDrivers;
			int nDriverCount;

			if(FAILED(g_DShowCaptureGraph.GetDriverList(&ptszCameraDrivers, &nDriverCount)))
			{
				RETAILMSG(1, ( TEXT("CameraDShowApp: Retrieving the driver list failed.")));
			} 

			g_DShowCaptureGraph.SelectCameraDevice(0);

			g_dwFilters = VIDEO_CAPTURE_FILTER | VIDEO_RENDERER | STILL_IMAGE_SINK | FILE_WRITER | VIDEO_ENCODER ;
			
			//g_dwFilters = VIDEO_CAPTURE_FILTER | VIDEO_RENDERER ;  
			
			wsprintf(g_tszStillFileName,L"%s",STILL_IMAGE_FILE_NAME);
			wsprintf(g_tszCaptureFileName,L"%s", VIDEO_CAPTURE_FILE_NAME);

			//g_dwFilters &=  ~AUDIO_ENCODER;
			//g_dwFilters &= ~AUDIO_CAPTURE_FILTER;
			//gAudioCapture = TRUE;

			rc.top = g_MenuBarHeight;
			rc.left = 0;
			rc.right = 0;
			rc.bottom = 0; 
			if(!g_bCameraSelected)
			{
				if(SUCCEEDED(g_DShowCaptureGraph.Init(hwnd, &rc, g_dwFilters )))
				{
						
						g_bCameraSelected = TRUE;

					
						

						hr = g_DShowCaptureGraph.RunGraph();
						if(FAILED(hr))
						{
							RETAILMSG(1, ( TEXT("CameraDShowApp: Starting the capture graph failed.")));
						}
						
						int iCount = 0, iSize = 0;
						
						if(! FAILED( hr = g_DShowCaptureGraph.GetNumberOfCapabilities(STREAM_CAPTURE,&iCount, &iSize)))
						{
							g_NumofCaptureResolutions = iCount;
							RETAILMSG(1, ( TEXT("WndProc : g_NumofCaptureResolutions = %lu\r\n"),g_NumofCaptureResolutions));
						}

						if(! FAILED( hr = g_DShowCaptureGraph.GetNumberOfCapabilities(STREAM_STILL,&iCount, &iSize)))
						{
							g_NumofStillResolutions = iCount;
						}

						GetCurrentVideoResolution();
						GetCurrentStillResolution();

						hr = g_DShowCaptureGraph.SetStillCaptureFileName(g_tszStillFileName);
						if(FAILED(hr))
						{
							RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to set the still image file name.")));
						}

						hr = g_DShowCaptureGraph.SetVideoCaptureFileName(g_tszCaptureFileName);
						if(FAILED(hr))
						{
							RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to set the video capture file name.")));
						}
				} 
				else
				{
					RETAILMSG(1, ( TEXT("CameraDShowApp: Initializing the capture graph failed.")));
				} 
			}
					

			
           break;

		case WM_PAINT:
			hdc = BeginPaint(hwnd, &ps); 
            // TODO: Add any drawing code here...
            EndPaint(hwnd, &ps);
            break;

        case WM_DESTROY:
			hr = g_DShowCaptureGraph.Cleanup();
			if(FAILED(hr))
            {
                RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to clean up the previously running capture graph.")));
            }
			CommandBar_Destroy(g_Hwnd);
            PostQuitMessage(0);
			return (0);
            break;
            
        case WM_COMMAND:
            wmId    = LOWORD(wParam); 
            wmEvent = HIWORD(wParam); 
            // Parse the menu selections:
            switch (wmId)
            {
                case IDM_HELP_ABOUT:
                    //DialogBox(g_hInstance, (LPCTSTR)IDD_ABOUTBOX, hwnd, About);
                    break;
                case IDM_FILE_EXIT:
                    DestroyWindow(hwnd);
                    break;
				case ID_OPTIONS_CAMERASELECT:
					{
						DialogBox(g_hInstance, (LPCTSTR)IDD_FORMATSELECTPAGE, hwnd, (DLGPROC)FormatSelectDialog);					

						//g_dwFilters &=  ~AUDIO_ENCODER;
						//g_dwFilters &= ~AUDIO_CAPTURE_FILTER;

						rc.top = g_MenuBarHeight;
						rc.left = 0;
						rc.right = 0;
						rc.bottom = 0; 
						
						if(g_bCameraSelected)
							g_DShowCaptureGraph.Cleanup();
						
						if(SUCCEEDED(g_DShowCaptureGraph.Init(hwnd, &rc, g_dwFilters )))
						{
								g_bCameraSelected = TRUE;
								hr = g_DShowCaptureGraph.RunGraph();
								if(FAILED(hr))
								{
									RETAILMSG(1, ( TEXT("CameraDShowApp: Starting the capture graph failed.")));
								}

								
								int iCount = 0, iSize = 0;
								
								if(! FAILED( hr = g_DShowCaptureGraph.GetNumberOfCapabilities(STREAM_CAPTURE,&iCount, &iSize)))
								{
									g_NumofCaptureResolutions = iCount;
									RETAILMSG(1, ( TEXT("WndProc : g_NumofCaptureResolutions = %lu\r\n"),g_NumofCaptureResolutions));
								}

								if(! FAILED( hr = g_DShowCaptureGraph.GetNumberOfCapabilities(STREAM_STILL,&iCount, &iSize)))
								{
									g_NumofStillResolutions = iCount;
								}
								
								GetCurrentVideoResolution();
								GetCurrentStillResolution();

								hr = g_DShowCaptureGraph.SetStillCaptureFileName(g_tszStillFileName);
								if(FAILED(hr))
								{
									RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to set the still image file name.")));
								}

								hr = g_DShowCaptureGraph.SetVideoCaptureFileName(g_tszCaptureFileName);
								if(FAILED(hr))
								{
									RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to set the video capture file name.")));
								}
						} 
						else
						{
							RETAILMSG(1, ( TEXT("CameraDShowApp: Initializing the capture graph failed.")));
						} 
					}
					break;

				case ID_OPTIONS_VIDEOCAPTUREPIN:
					DialogBox(g_hInstance, (LPCTSTR)IDD_CAPTUREPIN, hwnd, CapturePinDialogProc);
					break;

				case ID_OPTIONS_VIDEOPROPERTY:
					DialogBox(g_hInstance, (LPCTSTR)IDD_CAMERAPROP, hwnd, CameraProDialogProc);
					break;

				case ID_OPTIONS_CAMERAPROPERTY:
					DialogBox(g_hInstance, (LPCTSTR)IDD_CAMERACONTROLPROP, hwnd, CameraControlProDialogProc);
					break;

				case ID_CAPTURE_STILLCAPTURE:
					DWORD startTime,endTime;

					//If Still Image Resolution is less than Capture Resolution..It will change the camera resolution and 
					//will take a picture and back to capture resolution.. it will take 15 seconds to get a still in high resolution.		
					
					//CAMFORMATPROS tmpCapRes;
					//CAMFORMATPROS tmpStillRes;
					//GetResolution(STREAM_CAPTURE,&tmpCapRes,g_CaptureResolutionIndex);
					//GetResolution(STREAM_STILL,&tmpStillRes,g_StillResolutionIndex);

					//if(tmpCapRes.width != tmpStillRes.width || tmpCapRes.height != tmpStillRes.height)
					if(0)
					{
							CAMFORMATPROS tempResolution3;
							
							startTime = GetTickCount();					
							GetVideoProfile(STREAM_CAPTURE,g_StillResolutionIndex,STREAM_STILL);
							GetVideoProfile(STREAM_STILL,g_StillResolutionIndex,STREAM_STILL);
							GetResolution(STREAM_STILL,&tempResolution3,g_StillResolutionIndex);
							
							rc.top = GetSystemMetrics(SM_CXSCREEN); //set outside Display position to hide fron user 
							rc.left = 0;
							rc.right = 0; 
							rc.bottom = 0;   
							
							/* rc.top = GetSystemMetrics(SM_CXSCREEN); 
							rc.left = 0;
							rc.right = tempResolution3.width; 
							rc.bottom = tempResolution3.height + g_MenuBarHeight;   */
						
							//g_CaptureResolutionIndex = index;
							endTime = GetTickCount();
							
							startTime = GetTickCount();
							g_DShowCaptureGraph.Cleanup();
							endTime = GetTickCount();
							
							startTime = GetTickCount();
							hr = g_DShowCaptureGraph.SetFormat(STREAM_CAPTURE,g_CurrentVideoProfile);
							if (! SUCCEEDED(hr))
							{
								RETAILMSG(1,(TEXT("SetFormat Fails\r\n")));
							}
							hr = g_DShowCaptureGraph.SetFormat(STREAM_STILL,g_CurrentStillProfile);
							if (! SUCCEEDED(hr))
							{
								RETAILMSG(1,(TEXT("SetFormat Fails\r\n")));
							}
							endTime = GetTickCount();

							startTime = GetTickCount();
							//RETAILMSG(DEBUG_ENABLE,(TEXT("rc.right = %lu, rc.bottom = %lu, rc.top = %lu\r\n"),rc.right,rc.bottom,rc.top));
							if(SUCCEEDED(g_DShowCaptureGraph.Init(g_Hwnd, &rc, g_dwFilters)))
							{                													
								
								endTime = GetTickCount();
								
								startTime = GetTickCount();
								hr = g_DShowCaptureGraph.SetStillCaptureFileName(g_tszStillFileName);
								if(FAILED(hr))
								{
									RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to set the still image file name.")));
								}

								hr = g_DShowCaptureGraph.SetVideoCaptureFileName(g_tszCaptureFileName);
								if(FAILED(hr))
								{
									RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to set the video capture file name.")));
								}
								endTime = GetTickCount();

								startTime = GetTickCount();
								hr = g_DShowCaptureGraph.RunGraph();
								if(FAILED(hr))
								{
									RETAILMSG(1, ( TEXT("CameraDShowApp: Starting the capture graph failed.")));
								}
								endTime = GetTickCount();
							
								startTime = GetTickCount();
								hr = g_DShowCaptureGraph.CaptureStillImage(); //g_DShowCaptureGraph.CaptureStillImageBurst(1);

						        if(FAILED(hr))
					            {
									RETAILMSG(1, ( TEXT("CameraDShowApp: Capturing a still image failed.")));
								}
								endTime = GetTickCount();
							}

							startTime = GetTickCount();	
							GetVideoProfile(STREAM_CAPTURE,g_CaptureResolutionIndex,STREAM_CAPTURE);
							GetVideoProfile(STREAM_STILL,g_CaptureResolutionIndex,STREAM_CAPTURE);
							GetResolution(STREAM_CAPTURE,&tempResolution3,g_CaptureResolutionIndex);
						
							rc.top = g_MenuBarHeight;
							rc.left = 0;
							rc.right = tempResolution3.width;
							rc.bottom = tempResolution3.height + g_MenuBarHeight;  
							endTime = GetTickCount();
							
							startTime = GetTickCount();
							g_DShowCaptureGraph.Cleanup();
							endTime = GetTickCount();

							startTime = GetTickCount();
							hr = g_DShowCaptureGraph.SetFormat(STREAM_CAPTURE,g_CurrentVideoProfile);
							if (! SUCCEEDED(hr))
							{
								RETAILMSG(1,(TEXT("SetFormat Fails\r\n")));
							}
							hr = g_DShowCaptureGraph.SetFormat(STREAM_STILL,g_CurrentStillProfile);
							if (!SUCCEEDED(hr))
							{
								RETAILMSG(1,(TEXT("SetFormat Fails\r\n")));
							}
							endTime = GetTickCount();

							startTime = GetTickCount();
							//RETAILMSG(DEBUG_ENABLE,(TEXT("rc.right = %lu, rc.bottom = %lu, rc.top = %lu\r\n"),rc.right,rc.bottom,rc.top));
							if(SUCCEEDED(g_DShowCaptureGraph.Init(g_Hwnd, &rc, g_dwFilters)))
							{                													
								endTime = GetTickCount();
								
								startTime = GetTickCount();
								hr = g_DShowCaptureGraph.SetStillCaptureFileName(g_tszStillFileName);
								if(FAILED(hr))
								{
									RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to set the still image file name.")));
								}
								hr = g_DShowCaptureGraph.SetVideoCaptureFileName(g_tszCaptureFileName);
								if(FAILED(hr))
								{
									RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to set the video capture file name.")));
								}
								endTime = GetTickCount();

								startTime = GetTickCount();
								hr = g_DShowCaptureGraph.RunGraph();
								if(FAILED(hr))
								{
									RETAILMSG(1, ( TEXT("CameraDShowApp: Starting the capture graph failed.")));
								}
								endTime = GetTickCount();
							}

						}
					else
					{
						//Take a still image
						startTime = GetTickCount();
						hr = g_DShowCaptureGraph.CaptureStillImage();//g_DShowCaptureGraph.CaptureStillImageBurst(1);

						if(FAILED(hr))
						{
							RETAILMSG(1, ( TEXT("CameraDShowApp: Capturing a still image failed.")));
						}
						endTime = GetTickCount();
					}
                    break;

				case ID_CAPTURE_STARTCAPTURE:
                    g_nFramesProcessed = 0;
                    g_nOOMEvents = 0;
					
					//EnableWindow(ID_CAPTURE_STARTCAPTURE,FALSE);
					
					if(g_bVideoRecord)
					{

						MessageBox(g_Hwnd,L"Already Video Recording",L"DShowTestApp",MB_ICONINFORMATION);
					}
					else
					{
							//if(gAudioCapture)
						//	g_dwFilters |= AUDIO_CAPTURE_FILTER;
						//if(gAudioEncoder)
						//	g_dwFilters |= AUDIO_ENCODER;
						g_bVideoRecord = TRUE;
						hr = g_DShowCaptureGraph.GetCurrentPosition(&g_rtCaptureStart);
						if(FAILED(hr))
						{
							RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to retrieve the current graph position.")));
						}

						hr = g_DShowCaptureGraph.StartStreamCapture();
						if(FAILED(hr))
						{
							RETAILMSG(1, ( TEXT("CameraDShowApp: Starting the video capture failed.")));
						}
						g_bCapturePaused = FALSE;
					}
                    break;
                case ID_CAPTURE_PAUSECAPTURE:

                    // if we're currently paused, then restart.
                    if(g_bCapturePaused)
                    {
                        hr = g_DShowCaptureGraph.StartStreamCapture();
                        if(FAILED(hr))
                        {
                            RETAILMSG(1, ( TEXT("CameraDShowApp: Resuming the capture failed.")));
                        }
                        g_bCapturePaused = FALSE;
                        
                    }
                    else
                    {
                        hr = StopStreamCapture();
                        if(FAILED(hr))
                        {
                            RETAILMSG(1, ( TEXT("CameraDShowApp: pausing the capture failed.")));
                        }
                        g_bCapturePaused = TRUE;                       
                    }
                    break;
                case ID_CAPTURE_STOPCAPTURE:
                    
					//if(gAudioCapture)
					//	g_dwFilters &= ~AUDIO_CAPTURE_FILTER;
					//if(gAudioEncoder)
					//	g_dwFilters &= ~AUDIO_ENCODER;
					

                    hr = StopStreamCapture();
                    if(FAILED(hr))
                    {
                        RETAILMSG(1, ( TEXT("Stopping the video capture failed.")));
                    }

                    if(FAILED(g_DShowCaptureGraph.StopGraph()))
                    {
                        FAIL(TEXT("Failed to stop the capture graph after the capture."));
                    }

                    SendMessage(g_hwndEncodeStatus, PBM_SETPOS, 100, 0);

                    Log(TEXT("Verifying the video file."));

                    if(FAILED(g_DShowCaptureGraph.VerifyVideoFileCaptured(NULL)))
                    {
                        RETAILMSG(1, (TEXT("The video file captured failed file conformance verification")));
                    }
					g_bVideoRecord = FALSE;
					

                    if(FAILED(g_DShowCaptureGraph.RunGraph()))
                    {
                        FAIL(TEXT("Failed to stop the capture graph after the capture."));
                    }
                    g_bCapturePaused = FALSE;

                    break;
				case ID_CAPTURE_ACTUALFRAMERATE:	
					TCHAR dbgMsg[MAX_PATH];
					VIDEORENDERER_STATS GetFrameRate;
					g_DShowCaptureGraph.GetVideoRenderStats(&GetFrameRate);
					break;
				default:
                    return DefWindowProc(hwnd, msg, wParam, lParam);
            }
            break;
    		default:
				break;
    }
    return DefWindowProc(hwnd, msg, wParam, lParam);
}
//
//  FUNCTION:WinMain
//
//  PURPOSE: 
//
//  COMMENTS:
//
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPTSTR    lpCmdLine,
                   int       nCmdShow)
{
	MSG msg;
    
	// Perform application initialization:
		if (!InitInstance(hInstance, nCmdShow)) 
		{
			return FALSE;
		}

		HACCEL hAccelTable;
		hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_DSHOW_TEST_APP));

	// Main message loop:
		while (GetMessage(&msg, NULL, 0, 0)) 
		{
			if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
			{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}
		//UnregisterClass(szWindowClass, g_hInstance);
	return (int) msg.wParam;
}

//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
ATOM MyRegisterClass(HINSTANCE hInstance, LPTSTR szWindowClass)
{
	WNDCLASS wc;

	wc.style         = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc   = WndProc;
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = 0;
	wc.hInstance     = hInstance;
	wc.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_DSHOW_TEST_APP));
	wc.hCursor       = 0;
	wc.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
	wc.lpszMenuName  = 0;
	wc.lpszClassName = szWindowClass;

	return RegisterClass(&wc);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    HWND hWnd;
    TCHAR szTitle[MAX_LOADSTRING];		// title bar text
    TCHAR szWindowClass[MAX_LOADSTRING];	// main window class name

    g_hInstance = hInstance; // Store instance handle in our global variable


    LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING); 
    LoadString(hInstance, IDC_DSHOW_TEST_APP, szWindowClass, MAX_LOADSTRING);


    if (!MyRegisterClass(hInstance, szWindowClass))
    {
    	return FALSE;
    }
	
	if(FAILED(g_DShowCaptureGraph.InitCameraDriver()))
	{
		RETAILMSG(1, ( TEXT("CameraDShowApp: Initializing the camera driver list failed.")));
		MessageBox(NULL,L"Verify Camera is Connected",L"DShowTestApp",MB_ICONINFORMATION);
		return FALSE;
	}	

    g_Hwnd =hWnd = CreateWindow(szWindowClass, szTitle, WS_VISIBLE,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL);

    if (!hWnd)
    {
        return FALSE;
    }


    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);
	//SetForegroundWindow(hWnd);
	if (g_Hwnd)
    {
        CommandBar_Show(g_Hwnd, TRUE);
    }

   
    return TRUE;
}
//
//  FUNCTION: CameraProDialogProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Camera Video Control Properties change window.
//
//  
INT_PTR CALLBACK CameraProDialogProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	HRESULT hr ;
	short int nPos;
	HANDLE hwndScrollBar;
	short int userReq ;

	switch (message)
    {
        case WM_INITDIALOG:
            RECT rectChild, rectParent;
            int DlgWidth, DlgHeight;	// dialog width and height in pixel units
            int NewPosX, NewPosY;
            // trying to center the About dialog
            if (GetWindowRect(hDlg, &rectChild)) 
            {
                GetClientRect(GetParent(hDlg), &rectParent);
                DlgWidth	= rectChild.right - rectChild.left;
                DlgHeight	= rectChild.bottom - rectChild.top ;
                //NewPosX		= (rectParent.right - rectParent.left - DlgWidth) / 2;
                //NewPosY		= (rectParent.bottom - rectParent.top - DlgHeight) / 2;
				NewPosX = 0;
				NewPosY = 0;
                // if the About box is larger than the physical screen 
                if (NewPosX < 0) NewPosX = 0;
                if (NewPosY < 0) NewPosY = 0;
                SetWindowPos(hDlg, 0, NewPosX, NewPosY,
                    0, 0, SWP_NOZORDER | SWP_NOSIZE);

				//g_DShowCaptureGraph.Get(PROPERTY_CAMERACONTROL,CameraControl_Zoom, (long *)&BrightValue,(long *)&BrightFlag);
				
			
				for(PropNum=0; PropNum<NUMBER_OF_PROP; PropNum++)
				{
					hr = S_OK;
					if( FAILED( hr = g_DShowCaptureGraph.GetRange(PROPERTY_VIDPROCAMP,CameraVideoProperties[PropNum].VideoProper,(long *)&PropMin,(long *)&PropMax,(long *)&PropStepping,(long *)&PropDefault,(long *)&PropFlag)))
					{
						CameraVideoProperties[PropNum].bSupport = FALSE;
						EnableWindow(GetDlgItem(hDlg,CameraVideoProperties[PropNum].IDCCheck),FALSE);
						EnableWindow(GetDlgItem(hDlg,CameraVideoProperties[PropNum].IDCEditValue),FALSE);
						EnableWindow(GetDlgItem(hDlg,CameraVideoProperties[PropNum].IDCSlid),FALSE);
						RETAILMSG(DEBUG_ENABLE,(TEXT("CameraVideoProperties[PropNum] is not supported\r\n"),PropNum));	
						continue;
					}
					RETAILMSG(DEBUG_ENABLE,(TEXT("VideoProcAmp  PropMin = %d PropMax = %d PropStepping = %d PropDefault = %d PropFlag = %d\r\n" ),PropMin,PropMax,PropStepping,PropDefault,PropFlag ));
					if(PropFlag & CameraControl_Flags_Auto)
					{
						CameraVideoProperties[PropNum].bAutoSupport = TRUE;	
					}
					else
					{
						EnableWindow(GetDlgItem(hDlg,CameraVideoProperties[PropNum].IDCCheck),FALSE);
						RETAILMSG(DEBUG_ENABLE,(TEXT("CameraVideoProperties[PropNum] Check box Gray\r\n"),PropNum));				
					}
					g_DShowCaptureGraph.Get(PROPERTY_VIDPROCAMP,CameraVideoProperties[PropNum].VideoProper,(long *)&PropValue,(long *)&PropFlag);
					RETAILMSG(DEBUG_ENABLE,(TEXT("VideoProcAmp  PropValue = %d PropFlag = %d" ),PropValue,PropFlag));
					
					CameraVideoProperties[PropNum].Value = PropValue;
					CameraVideoProperties[PropNum].Default = PropDefault; 
					CameraVideoProperties[PropNum].hSlid = GetDlgItem(hDlg,CameraVideoProperties[PropNum].IDCSlid);
					SendMessage(CameraVideoProperties[PropNum].hSlid,TBM_SETRANGE,TRUE,(LPARAM) MAKELONG (PropMin, PropMax));
					SendMessage(CameraVideoProperties[PropNum].hSlid,TBM_SETPOS,TRUE,(LPARAM) PropValue);
					SetDlgItemInt(hDlg,CameraVideoProperties[PropNum].IDCEditValue,PropValue,FALSE);
					
					if (PropFlag == CameraControl_Flags_Auto)
					{
						CameraVideoProperties[PropNum].bAuto = TRUE;
						SendDlgItemMessage(hDlg, CameraVideoProperties[PropNum].IDCCheck, BM_SETCHECK, BST_CHECKED, 0);
						CameraVideoPropAutoUpdate(hDlg,PropNum,TRUE);
					}
					else
					{
						CameraVideoProperties[PropNum].bAuto = FALSE;
					}
				}
				EnableWindow(GetDlgItem(hDlg,IDC_APPLY),FALSE);
				
				for(PropNum=0; PropNum<NUMBER_OF_PROP; PropNum++)
				{
					RETAILMSG(DEBUG_ENABLE,(TEXT("CameraVideoProperties[%d].VideoProper = %d \r\n"),PropNum,CameraVideoProperties[PropNum].VideoProper));
					RETAILMSG(DEBUG_ENABLE,(TEXT("CameraVideoProperties[%d].Value = %d \r\n"),PropNum,CameraVideoProperties[PropNum].Value));
					RETAILMSG(DEBUG_ENABLE,(TEXT("CameraVideoProperties[%d].Default = %d \r\n"),PropNum,CameraVideoProperties[PropNum].Default));
					RETAILMSG(DEBUG_ENABLE,(TEXT("CameraVideoProperties[%d].hSlid = 0x%X \r\n"),PropNum,CameraVideoProperties[PropNum].hSlid));
					RETAILMSG(DEBUG_ENABLE,(TEXT("CameraVideoProperties[%d].hEditValue = 0x%X \r\n"),PropNum,CameraVideoProperties[PropNum].hEditValue));
					RETAILMSG(DEBUG_ENABLE,(TEXT("CameraVideoProperties[%d].bAuto = %d \r\n"),PropNum,CameraVideoProperties[PropNum].bAuto));
					RETAILMSG(DEBUG_ENABLE,(TEXT("CameraVideoProperties[%d].IDCSlid = %d \r\n"),PropNum,CameraVideoProperties[PropNum].IDCSlid));
					RETAILMSG(DEBUG_ENABLE,(TEXT("CameraVideoProperties[%d].IDCEditValue = %d \r\n"),PropNum,CameraVideoProperties[PropNum].IDCEditValue));
					RETAILMSG(DEBUG_ENABLE,(TEXT("CameraVideoProperties[%d].bSupport = %d \r\n"),PropNum,CameraVideoProperties[PropNum].bSupport));
				}
			}			
            return (INT_PTR)TRUE;
        case WM_COMMAND:
			switch ((int)LOWORD(wParam))
	        {				
				case IDC_BRIGHTNESSCHECK:
					nChecked = SendDlgItemMessage(hDlg, CameraVideoProperties[0].IDCCheck, BM_GETCHECK, 0, 0);
					//CameraVideoProperties[0].bAuto = (BST_CHECKED == nChecked);
					CameraVideoPropAutoUpdate(hDlg,0,nChecked);
					break;
				
				case IDC_CONTRASTCHECK:
					nChecked = SendDlgItemMessage(hDlg, CameraVideoProperties[1].IDCCheck, BM_GETCHECK, 0, 0);
					//CameraVideoProperties[1].bAuto = (BST_CHECKED == nChecked);
					CameraVideoPropAutoUpdate(hDlg,1,nChecked);
					break;

				case IDC_HUECHECK:
					nChecked = SendDlgItemMessage(hDlg, CameraVideoProperties[2].IDCCheck, BM_GETCHECK, 0, 0);
					//CameraVideoProperties[2].bAuto = (BST_CHECKED == nChecked);
					CameraVideoPropAutoUpdate(hDlg,2,nChecked);
					break;

				case IDC_SATURATIONCHECK:
					nChecked = SendDlgItemMessage(hDlg, CameraVideoProperties[3].IDCCheck, BM_GETCHECK, 0, 0);
					//CameraVideoProperties[3].bAuto = (BST_CHECKED == nChecked);
					CameraVideoPropAutoUpdate(hDlg,3,nChecked);
					break;
				case IDC_SHARPNESSCHECK:
					nChecked = SendDlgItemMessage(hDlg, CameraVideoProperties[4].IDCCheck, BM_GETCHECK, 0, 0);
					//CameraVideoProperties[4].bAuto = (BST_CHECKED == nChecked);
					CameraVideoPropAutoUpdate(hDlg,4,nChecked);
					break;
				case IDC_GAMMACHECK:
					nChecked = SendDlgItemMessage(hDlg, CameraVideoProperties[5].IDCCheck, BM_GETCHECK, 0, 0);
					//CameraVideoProperties[5].bAuto = (BST_CHECKED == nChecked);
					CameraVideoPropAutoUpdate(hDlg,5,nChecked);
					break;
				case IDC_WHITEBALANCECHECK:
					nChecked = SendDlgItemMessage(hDlg, CameraVideoProperties[6].IDCCheck, BM_GETCHECK, 0, 0);
					//CameraVideoProperties[6].bAuto = (BST_CHECKED == nChecked);
					CameraVideoPropAutoUpdate(hDlg,6,nChecked);
					break;
				case IDC_BACKLIGHTCHECK:
					nChecked = SendDlgItemMessage(hDlg, CameraVideoProperties[7].IDCCheck, BM_GETCHECK, 0, 0);
					//CameraVideoProperties[7].bAuto = (BST_CHECKED == nChecked);
					CameraVideoPropAutoUpdate(hDlg,7,nChecked);
					break;
				case IDC_APPLY :
					for(PropNum=0; PropNum<NUMBER_OF_PROP; PropNum++)
					{
						if(CameraVideoProperties[PropNum].bSupport)
						{
						g_DShowCaptureGraph.Get(PROPERTY_VIDPROCAMP,CameraVideoProperties[PropNum].VideoProper,(long *)&PropValue,(long *)&PropFlag);
						CameraVideoProperties[PropNum].Value = PropValue;
						if( SendDlgItemMessage(hDlg, CameraVideoProperties[PropNum].IDCCheck, BM_GETCHECK, 0, 0))
						{
							CameraVideoProperties[PropNum].bAuto = TRUE;
						}
						}
					}
					break;
				case IDC_OK:
					for(PropNum=0; PropNum<NUMBER_OF_PROP; PropNum++)
					{					
						if(CameraVideoProperties[PropNum].bSupport)
						{
						g_DShowCaptureGraph.Get(PROPERTY_VIDPROCAMP,CameraVideoProperties[PropNum].VideoProper,(long *)&PropValue,(long *)&PropFlag);
						CameraVideoProperties[PropNum].Value = PropValue;
						}
					}
					EndDialog(hDlg, message);
					return TRUE;
					
				case IDC_CANCEL:
					for(PropNum=0; PropNum<NUMBER_OF_PROP; PropNum++)
					{
						if(CameraVideoProperties[PropNum].bSupport)
						{
						if(!CameraVideoProperties[PropNum].bAuto )
						{
							g_DShowCaptureGraph.Set(PROPERTY_VIDPROCAMP,CameraVideoProperties[PropNum].VideoProper,(long )CameraVideoProperties[PropNum].Value,CameraControl_Flags_Manual);
							SendMessage(CameraVideoProperties[PropNum].hSlid,TBM_SETPOS,TRUE,(LPARAM) CameraVideoProperties[PropNum].Value);
							SetDlgItemInt(hDlg,CameraVideoProperties[PropNum].IDCEditValue,CameraVideoProperties[PropNum].Value,FALSE);				
						}		
						}
					}
					EndDialog(hDlg, message);
					return TRUE;
					
				case IDC_DEFAULT:
					for(PropNum=0; PropNum<NUMBER_OF_PROP; PropNum++)
					{
						if(CameraVideoProperties[PropNum].bSupport)
						{
						if(! CameraVideoProperties[PropNum].bAuto)
						{
						EnableWindow(GetDlgItem(hDlg,IDC_APPLY),TRUE);
						g_DShowCaptureGraph.Set(PROPERTY_VIDPROCAMP,CameraVideoProperties[PropNum].VideoProper,(long )CameraVideoProperties[PropNum].Default,CameraControl_Flags_Manual);
						SendMessage(CameraVideoProperties[PropNum].hSlid,TBM_SETPOS,TRUE,(LPARAM)CameraVideoProperties[PropNum].Default);
						SetDlgItemInt(hDlg,CameraVideoProperties[PropNum].IDCEditValue,CameraVideoProperties[PropNum].Default,FALSE);
						}
						}
					}
					break;
			}
			break;

		case WM_HSCROLL:
			{	
				userReq = (int)LOWORD(wParam);
				if (userReq == SB_THUMBTRACK || userReq == SB_THUMBPOSITION || userReq == SB_ENDSCROLL)
				{
						//nPos = (short int)HIWORD(wParam);
						hwndScrollBar = (HWND) lParam;
						for(PropNum=0; PropNum < NUMBER_OF_PROP; PropNum++)
						{
							if(CameraVideoProperties[PropNum].hSlid == hwndScrollBar)
							{
								nPos = SendMessage(CameraVideoProperties[PropNum].hSlid,TBM_GETPOS,0,(LPARAM) 0);
								SetDlgItemInt(hDlg,CameraVideoProperties[PropNum].IDCEditValue,nPos,FALSE);
								RETAILMSG(DEBUG_ENABLE,(TEXT("CameraVideoProperties[PropNum].Value = %d\r\n" ),nPos));
								g_DShowCaptureGraph.Set(PROPERTY_VIDPROCAMP,CameraVideoProperties[PropNum].VideoProper, nPos, CameraControl_Flags_Manual);

							}	
						}
						EnableWindow(GetDlgItem(hDlg,IDC_APPLY),TRUE);
				}
			}
			break;
        case WM_CLOSE:
			for(PropNum=0; PropNum<NUMBER_OF_PROP; PropNum++)
			{
						if(CameraVideoProperties[PropNum].bSupport)
						{
						if(!CameraVideoProperties[PropNum].bAuto )
						{
							g_DShowCaptureGraph.Set(PROPERTY_VIDPROCAMP,CameraVideoProperties[PropNum].VideoProper,(long )CameraVideoProperties[PropNum].Value,CameraControl_Flags_Manual);
							SendMessage(CameraVideoProperties[PropNum].hSlid,TBM_SETPOS,TRUE,(LPARAM) CameraVideoProperties[PropNum].Value);
							SetDlgItemInt(hDlg,CameraVideoProperties[PropNum].IDCEditValue,CameraVideoProperties[PropNum].Value,FALSE);				
						}		
						}
			}
            EndDialog(hDlg, message);
            return TRUE;
    }
    return (INT_PTR)FALSE;
}
//
//  FUNCTION: CameraVideoPropAutoUpdate(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE: Radio Button Control
//
//
HRESULT CameraVideoPropAutoUpdate(HWND hDlg,int VideoProp,int AutoChecked)		
{
	HRESULT hr = S_OK;
	
		if(AutoChecked)
		{
			EnableWindow(CameraVideoProperties[VideoProp].hSlid, FALSE);
			SetDlgItemText(hDlg,CameraVideoProperties[VideoProp].IDCEditValue,L"Auto");				
			EnableWindow(GetDlgItem(hDlg,CameraVideoProperties[VideoProp].IDCEditValue),FALSE);
			hr = g_DShowCaptureGraph.Set(PROPERTY_VIDPROCAMP,CameraVideoProperties[VideoProp].VideoProper, 0, CameraControl_Flags_Auto);
		}
		else
		{
			g_DShowCaptureGraph.GetRange(PROPERTY_VIDPROCAMP,CameraVideoProperties[VideoProp].VideoProper,(long *)&PropMin,(long *)&PropMax,(long *)&PropStepping,(long *)&PropDefault,(long *)&PropFlag);
			if(PropFlag & CameraControl_Flags_Manual)
			{
				EnableWindow(CameraVideoProperties[VideoProp].hSlid, TRUE);
				EnableWindow(GetDlgItem(hDlg,CameraVideoProperties[VideoProp].IDCEditValue),TRUE);
				RETAILMSG(DEBUG_ENABLE,(TEXT("CameraVideoProperties[%d].Value = %d %d\r\n" ),VideoProp,PropValue,PropFlag));
				g_DShowCaptureGraph.Get(PROPERTY_VIDPROCAMP,CameraVideoProperties[VideoProp].VideoProper,(long *)&PropValue,(long *)&PropFlag);				
				g_DShowCaptureGraph.Set(PROPERTY_VIDPROCAMP,CameraVideoProperties[VideoProp].VideoProper,(long)PropValue,(long)CameraControl_Flags_Manual);				
				SetDlgItemInt(hDlg,CameraVideoProperties[VideoProp].IDCEditValue,PropValue,FALSE);				
			}
		}				
	EnableWindow(GetDlgItem(hDlg,IDC_APPLY),TRUE);
	return hr;
}
//
//  FUNCTION: CameraControlProDialogProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Camera Control Property change window
//
//
INT_PTR CALLBACK CameraControlProDialogProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	
	HRESULT hr ;
	INT32 nPos;
	HANDLE hwndScrollBar;
	short int userReq ;

	switch (message)
    {
        case WM_INITDIALOG:
            RECT rectChild, rectParent;
            int DlgWidth, DlgHeight;	// dialog width and height in pixel units
            int NewPosX, NewPosY;
            // trying to center the About dialog
            if (GetWindowRect(hDlg, &rectChild)) 
            {
                GetClientRect(GetParent(hDlg), &rectParent);
                DlgWidth	= rectChild.right - rectChild.left;
                DlgHeight	= rectChild.bottom - rectChild.top ;
                //NewPosX		= (rectParent.right - rectParent.left - DlgWidth) / 2;
                //NewPosY		= (rectParent.bottom - rectParent.top - DlgHeight) / 2;
				NewPosX = 0;
				NewPosY = 0;
                // if the About box is larger than the physical screen 
                if (NewPosX < 0) NewPosX = 0;
                if (NewPosY < 0) NewPosY = 0;
                SetWindowPos(hDlg, 0, NewPosX, NewPosY,
                    0, 0, SWP_NOZORDER | SWP_NOSIZE);

				//g_DShowCaptureGraph.Get(PROPERTY_CAMERACONTROL,CameraControl_Zoom, (long *)&BrightValue,(long *)&BrightFlag);
			
				for(PropNum=0; PropNum<NUMBER_OF_PROP; PropNum++)
				{
					hr = S_OK;
					if( FAILED( hr = g_DShowCaptureGraph.GetRange(PROPERTY_CAMERACONTROL,CameraControlProperties[PropNum].VideoProper,(long *)&PropMin,(long *)&PropMax,(long *)&PropStepping,(long *)&PropDefault,(long *)&PropFlag)))
					{
						CameraControlProperties[PropNum].bSupport = FALSE;
						EnableWindow(GetDlgItem(hDlg,CameraControlProperties[PropNum].IDCCheck),FALSE);
						EnableWindow(GetDlgItem(hDlg,CameraControlProperties[PropNum].IDCEditValue),FALSE);
						EnableWindow(GetDlgItem(hDlg,CameraControlProperties[PropNum].IDCSlid),FALSE);
						RETAILMSG(DEBUG_ENABLE,(TEXT("CameraControlProperties[PropNum] is not supported\r\n"),PropNum));	
						continue;
					}
					
					RETAILMSG(DEBUG_ENABLE,(TEXT("ControlProperty  PropMin = %d PropMax = %d PropStepping = %d PropDefault = %d PropFlag = %d\r\n" ),PropMin,PropMax,PropStepping,PropDefault,PropFlag ));
					if(PropFlag & CameraControl_Flags_Auto)
					{
						CameraControlProperties[PropNum].bAutoSupport = TRUE;	
					}
					else
					{
						EnableWindow(GetDlgItem(hDlg,CameraControlProperties[PropNum].IDCCheck),FALSE);
						RETAILMSG(DEBUG_ENABLE,(TEXT("CameraControlProperties[PropNum] Check box Gray\r\n"),PropNum));				
					}
					g_DShowCaptureGraph.Get(PROPERTY_CAMERACONTROL,CameraControlProperties[PropNum].VideoProper,(long *)&PropValue,(long *)&PropFlag);
					RETAILMSG(DEBUG_ENABLE,(TEXT("ControlProperty  PropValue = %d PropFlag = %d" ),PropValue,PropFlag));
					
					CameraControlProperties[PropNum].Value = PropValue;
					CameraControlProperties[PropNum].Default = PropDefault; 
					CameraControlProperties[PropNum].hSlid = GetDlgItem(hDlg,CameraControlProperties[PropNum].IDCSlid);
					//SendMessage(CameraControlProperties[PropNum].hSlid,TBM_SETRANGE,TRUE,(LPARAM) MAKELONG (PropMin, PropMax));
					SendMessage(CameraControlProperties[PropNum].hSlid,TBM_SETRANGEMIN,TRUE,(LPARAM)PropMin);
					SendMessage(CameraControlProperties[PropNum].hSlid,TBM_SETRANGEMAX,TRUE,(LPARAM)PropMax);
					SendMessage(CameraControlProperties[PropNum].hSlid,TBM_SETPOS,TRUE,(LPARAM) PropValue);
					SetDlgItemInt(hDlg,CameraControlProperties[PropNum].IDCEditValue,PropValue,FALSE);
					
					if (PropFlag == CameraControl_Flags_Auto)
					{
						RETAILMSG(DEBUG_ENABLE,(TEXT("Auto Perperty is set for CameraControlProperties[%d]"),PropNum));
						CameraControlProperties[PropNum].bAuto = TRUE;
						SendDlgItemMessage(hDlg, CameraControlProperties[PropNum].IDCCheck, BM_SETCHECK, BST_CHECKED, 0);
						CameraControlPropAutoUpdate(hDlg,PropNum,TRUE);
					}
					else
					{
						CameraControlProperties[PropNum].bAuto = FALSE;
					}
				}
				EnableWindow(GetDlgItem(hDlg,IDC_CCAPPLY),FALSE);
				
				for(PropNum=0; PropNum<NUMBER_OF_PROP; PropNum++)
				{
					RETAILMSG(DEBUG_ENABLE,(TEXT("CameraControlProperties[%d].VideoProper = %d \r\n"),PropNum,CameraControlProperties[PropNum].VideoProper));
					RETAILMSG(DEBUG_ENABLE,(TEXT("CameraControlProperties[%d].Value = %d \r\n"),PropNum,CameraControlProperties[PropNum].Value));
					RETAILMSG(DEBUG_ENABLE,(TEXT("CameraControlProperties[%d].Default = %d \r\n"),PropNum,CameraControlProperties[PropNum].Default));
					RETAILMSG(DEBUG_ENABLE,(TEXT("CameraControlProperties[%d].hSlid = 0x%X \r\n"),PropNum,CameraControlProperties[PropNum].hSlid));
					RETAILMSG(DEBUG_ENABLE,(TEXT("CameraControlProperties[%d].hEditValue = 0x%X \r\n"),PropNum,CameraControlProperties[PropNum].hEditValue));
					RETAILMSG(DEBUG_ENABLE,(TEXT("CameraControlProperties[%d].bAuto = %d \r\n"),PropNum,CameraControlProperties[PropNum].bAuto));
					RETAILMSG(DEBUG_ENABLE,(TEXT("CameraControlProperties[%d].IDCSlid = %d \r\n"),PropNum,CameraControlProperties[PropNum].IDCSlid));
					RETAILMSG(DEBUG_ENABLE,(TEXT("CameraControlProperties[%d].IDCEditValue = %d \r\n"),PropNum,CameraControlProperties[PropNum].IDCEditValue));
					RETAILMSG(DEBUG_ENABLE,(TEXT("CameraControlProperties[%d].bSupport = %d \r\n"),PropNum,CameraControlProperties[PropNum].bSupport));
				}
			}			
            return (INT_PTR)TRUE;
        case WM_COMMAND:
			switch ((int)LOWORD(wParam))
	        {				
				
				case IDC_PANCHECK:
					nChecked = SendDlgItemMessage(hDlg, CameraControlProperties[0].IDCCheck, BM_GETCHECK, 0, 0);
					//CameraControlProperties[0].bAuto = (BST_CHECKED == nChecked);
					CameraControlPropAutoUpdate(hDlg,0,nChecked);
					break;
				
				case IDC_TILTCHECK:
					nChecked = SendDlgItemMessage(hDlg, CameraControlProperties[1].IDCCheck, BM_GETCHECK, 0, 0);
					//CameraControlProperties[1].bAuto = (BST_CHECKED == nChecked);
					CameraControlPropAutoUpdate(hDlg,1,nChecked);
					break;

				case IDC_ROLLCHECK:
					nChecked = SendDlgItemMessage(hDlg, CameraControlProperties[2].IDCCheck, BM_GETCHECK, 0, 0);
					//CameraControlProperties[2].bAuto = (BST_CHECKED == nChecked);
					CameraControlPropAutoUpdate(hDlg,2,nChecked);
					break;

				case IDC_ZOOMCHECK:
					nChecked = SendDlgItemMessage(hDlg, CameraControlProperties[3].IDCCheck, BM_GETCHECK, 0, 0);
					//CameraControlProperties[3].bAuto = (BST_CHECKED == nChecked);
					CameraControlPropAutoUpdate(hDlg,3,nChecked);
					break;
				case IDC_IRISCHECK:
					nChecked = SendDlgItemMessage(hDlg, CameraControlProperties[4].IDCCheck, BM_GETCHECK, 0, 0);
					//CameraControlProperties[4].bAuto = (BST_CHECKED == nChecked);
					CameraControlPropAutoUpdate(hDlg,4,nChecked);
					break;
				case IDC_EXPOSURECHECK1:
					nChecked = SendDlgItemMessage(hDlg, CameraControlProperties[5].IDCCheck, BM_GETCHECK, 0, 0);
					//CameraControlProperties[5].bAuto = (BST_CHECKED == nChecked);
					CameraControlPropAutoUpdate(hDlg,5,nChecked);
					break;
				case IDC_FOCUSCHECK:
					nChecked = SendDlgItemMessage(hDlg, CameraControlProperties[6].IDCCheck, BM_GETCHECK, 0, 0);
					//CameraControlProperties[6].bAuto = (BST_CHECKED == nChecked);
					CameraControlPropAutoUpdate(hDlg,6,nChecked);
					break;
				case IDC_FLASHCHECK:
					nChecked = SendDlgItemMessage(hDlg, CameraControlProperties[7].IDCCheck, BM_GETCHECK, 0, 0);
					//CameraControlProperties[7].bAuto = (BST_CHECKED == nChecked);
					CameraControlPropAutoUpdate(hDlg,7,nChecked);
					break;
				case IDC_CCAPPLY :
					for(PropNum=0; PropNum<NUMBER_OF_PROP; PropNum++)
					{
						
						if(CameraControlProperties[PropNum].bSupport)
						{
						g_DShowCaptureGraph.Get(PROPERTY_CAMERACONTROL,CameraControlProperties[PropNum].VideoProper,(long *)&PropValue,(long *)&PropFlag);
						CameraControlProperties[PropNum].Value = PropValue;
						if( SendDlgItemMessage(hDlg, CameraControlProperties[PropNum].IDCCheck, BM_GETCHECK, 0, 0))
						{
							CameraControlProperties[PropNum].bAuto = TRUE;
						}
						}
					}
					break;
				case IDC_CCOK:
					for(PropNum=0; PropNum<NUMBER_OF_PROP; PropNum++)
					{					
						if(CameraControlProperties[PropNum].bSupport)
						{
						g_DShowCaptureGraph.Get(PROPERTY_CAMERACONTROL,CameraControlProperties[PropNum].VideoProper,(long *)&PropValue,(long *)&PropFlag);
						CameraControlProperties[PropNum].Value = PropValue;
						}
					}
					EndDialog(hDlg, message);
					return TRUE;
					
				case IDC_CCCANCEL:
					for(PropNum=0; PropNum<NUMBER_OF_PROP; PropNum++)
					{
						if(CameraControlProperties[PropNum].bSupport)
						{
							if(!CameraControlProperties[PropNum].bAuto )
							{
								g_DShowCaptureGraph.Set(PROPERTY_CAMERACONTROL,CameraControlProperties[PropNum].VideoProper,(long )CameraControlProperties[PropNum].Value,CameraControl_Flags_Manual);
								SendMessage(CameraControlProperties[PropNum].hSlid,TBM_SETPOS,TRUE,(LPARAM) CameraControlProperties[PropNum].Value);
								SetDlgItemInt(hDlg,CameraControlProperties[PropNum].IDCEditValue,CameraControlProperties[PropNum].Value,FALSE);				
							}
						}
					}
					EndDialog(hDlg, message);
					return TRUE;
					
				case IDC_CCDEFAULT:
					for(PropNum=0; PropNum<NUMBER_OF_PROP; PropNum++)
					{
						if(CameraControlProperties[PropNum].bSupport)
						{
						if(! CameraControlProperties[PropNum].bAuto)
						{
						EnableWindow(GetDlgItem(hDlg,IDC_CCAPPLY),TRUE);
						g_DShowCaptureGraph.Set(PROPERTY_CAMERACONTROL,CameraControlProperties[PropNum].VideoProper,(long )CameraControlProperties[PropNum].Default,CameraControl_Flags_Manual);
						SendMessage(CameraControlProperties[PropNum].hSlid,TBM_SETPOS,TRUE,(LPARAM)CameraControlProperties[PropNum].Default);
						SetDlgItemInt(hDlg,CameraControlProperties[PropNum].IDCEditValue,CameraControlProperties[PropNum].Default,FALSE);
						}
						}
					}
					break;
			}
			break;

		case WM_HSCROLL:
			{	
				userReq = (int)LOWORD(wParam);
				if (userReq == SB_THUMBTRACK || userReq == SB_THUMBPOSITION || userReq == SB_ENDSCROLL)
				{
						//nPos = (short int)HIWORD(wParam);
						hwndScrollBar = (HWND) lParam;
						for(PropNum=0; PropNum < NUMBER_OF_PROP; PropNum++)
						{
							if(CameraControlProperties[PropNum].hSlid == hwndScrollBar)
							{
								nPos = SendMessage(CameraControlProperties[PropNum].hSlid,TBM_GETPOS,0,(LPARAM) 0);
								SetDlgItemInt(hDlg,CameraControlProperties[PropNum].IDCEditValue,nPos,FALSE);
								RETAILMSG(DEBUG_ENABLE,(TEXT("CameraControlProperties[PropNum].Value = %d %d %d\r\n" ),nPos,PropNum,CameraControlProperties[PropNum].VideoProper));
								g_DShowCaptureGraph.Set(PROPERTY_CAMERACONTROL,CameraControlProperties[PropNum].VideoProper, nPos, CameraControl_Flags_Manual);

							}	
						}
						EnableWindow(GetDlgItem(hDlg,IDC_CCAPPLY),TRUE);
				}
			}
			break;
        case WM_CLOSE:
			for(PropNum=0; PropNum<NUMBER_OF_PROP; PropNum++)
			{
						if(CameraControlProperties[PropNum].bSupport)
						{
							if(!CameraControlProperties[PropNum].bAuto )
							{
								g_DShowCaptureGraph.Set(PROPERTY_CAMERACONTROL,CameraControlProperties[PropNum].VideoProper,(long )CameraControlProperties[PropNum].Value,CameraControl_Flags_Manual);
								SendMessage(CameraControlProperties[PropNum].hSlid,TBM_SETPOS,TRUE,(LPARAM) CameraControlProperties[PropNum].Value);
								SetDlgItemInt(hDlg,CameraControlProperties[PropNum].IDCEditValue,CameraControlProperties[PropNum].Value,FALSE);				
							}
						}
			}
            EndDialog(hDlg, message);
            return TRUE;
    }
    return (INT_PTR)FALSE;
}
//
//  FUNCTION: CameraControlPropAutoUpdate(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Radio button check control.
//
//
HRESULT CameraControlPropAutoUpdate(HWND hDlg,int VideoProp,int AutoChecked)		
{
	HRESULT hr = S_OK;
	
		if(AutoChecked)
		{	
			#if  AF_UVC_CAMERA_FIX 
			if( VideoProp == 5)
			{
				SendDlgItemMessage(hDlg, CameraControlProperties[VideoProp].IDCCheck, BM_SETCHECK, BST_UNCHECKED, 0);
				return ERROR_SUCCESS;
			}
			#endif  
			
			EnableWindow(CameraControlProperties[VideoProp].hSlid, FALSE);
			SetDlgItemText(hDlg,CameraControlProperties[VideoProp].IDCEditValue,L"Auto");				
			EnableWindow(GetDlgItem(hDlg,CameraControlProperties[VideoProp].IDCEditValue),FALSE);
			hr = g_DShowCaptureGraph.Set(PROPERTY_CAMERACONTROL,CameraControlProperties[VideoProp].VideoProper, 0, CameraControl_Flags_Auto);
		}
		else
		{
			#if  AF_UVC_CAMERA_FIX 
			if( VideoProp == 5)
			{
				SendDlgItemMessage(hDlg, CameraControlProperties[VideoProp].IDCCheck, BM_SETCHECK, BST_CHECKED, 0);
				return ERROR_SUCCESS;
			}
			#endif   
			
			g_DShowCaptureGraph.GetRange(PROPERTY_CAMERACONTROL,CameraControlProperties[VideoProp].VideoProper,(long *)&PropMin,(long *)&PropMax,(long *)&PropStepping,(long *)&PropDefault,(long *)&PropFlag);
			
			if(PropFlag & CameraControl_Flags_Manual)
			{
					EnableWindow(CameraControlProperties[VideoProp].hSlid, TRUE);
					EnableWindow(GetDlgItem(hDlg,CameraControlProperties[VideoProp].IDCEditValue),TRUE);	
					RETAILMSG(DEBUG_ENABLE,(TEXT("CameraControlProperties[%d].Value = %d %d\r\n" ),VideoProp,PropValue,PropFlag));
					g_DShowCaptureGraph.Get(PROPERTY_CAMERACONTROL,CameraControlProperties[VideoProp].VideoProper,(long *)&PropValue,(long *)&PropFlag);				
					g_DShowCaptureGraph.Set(PROPERTY_CAMERACONTROL,CameraControlProperties[VideoProp].VideoProper,(long)PropValue,(long)CameraControl_Flags_Manual);				
					SetDlgItemInt(hDlg,CameraControlProperties[VideoProp].IDCEditValue,PropValue,FALSE);				
			}			
			
		}				
	EnableWindow(GetDlgItem(hDlg,IDC_CCAPPLY),TRUE);
	return hr;
}
BOOL YUY2FormatAdded;
BOOL MJPGFormatAdded;
//
//  FUNCTION: CameraProDialogProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  It is for Camera Video Control Properties change window.
//
//
INT_PTR CALLBACK CapturePinDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
    {
        case WM_INITDIALOG:
		{
		   RECT rectChild, rectParent;
            int DlgWidth, DlgHeight;	// dialog width and height in pixel units
            int NewPosX, NewPosY;

            // trying to center the About dialog
            if (GetWindowRect(hDlg, &rectChild)) 
            {
                GetClientRect(GetParent(hDlg), &rectParent);
                DlgWidth	= rectChild.right - rectChild.left;
                DlgHeight	= rectChild.bottom - rectChild.top ;
                //NewPosX		= (rectParent.right - rectParent.left - DlgWidth) / 2;
                //NewPosY		= (rectParent.bottom - rectParent.top - DlgHeight) / 2;
				
				NewPosX = 0;
				NewPosY = 0;

                // if the About box is larger than the physical screen 
                if (NewPosX < 0) NewPosX = 0;
                if (NewPosY < 0) NewPosY = 0;
                SetWindowPos(hDlg, 0, NewPosX, NewPosY,
                    0, 0, SWP_NOZORDER | SWP_NOSIZE);

				g_hwndCapturePins = GetDlgItem(hDlg, IDC_CAPOUTPUT);
				g_hwndColorSpace = GetDlgItem(hDlg, IDC_CAPCOLOR);

				TCHAR OutString[MAX_PATH];
				TCHAR FormatString[MAX_PATH];
				CAMFORMATPROS tempResolution;
				
				RETAILMSG(DEBUG_ENABLE,(TEXT("g_NumofCaptureResolutions = %lu"),g_NumofCaptureResolutions));

				for(int i=0; i<g_NumofCaptureResolutions; i++)
				{
					

					GetResolution(STREAM_CAPTURE,&tempResolution,i);

					if(IsEqualGUID(tempResolution.subType, MEDIASUBTYPE_YUY2)) 
					{
						wsprintf(FormatString, TEXT("YUY2"));		
					}
					if(IsEqualGUID(tempResolution.subType, MEDIASUBTYPE_MJPG)) 
					{
						wsprintf(FormatString, TEXT("MJPG"));		
					}
					DWORD FrameRate = (1000 / (tempResolution.AvgTimePerFrame / 10000));
					//NKDbgPrintfW(L"%d FPS", FrameRate);
					wsprintf(OutString, L"%dx%d %s @ %d fps", tempResolution.width, tempResolution.height, FormatString, FrameRate);
					SendMessage(g_hwndCapturePins, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(OutString));
					
					/* if(IsEqualGUID(tempResolution.subType, MEDIASUBTYPE_YUY2)) 
					{
						if(!YUY2FormatAdded)
						{
							wsprintf(OutString, TEXT("YUY2"));	
							YUY2FormatAdded = TRUE;
							SendMessage(g_hwndColorSpace, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(OutString));
						}
					}
					if(IsEqualGUID(tempResolution.subType, MEDIASUBTYPE_MJPG)) 
					{
						if(!MJPGFormatAdded)
						{
							wsprintf(OutString, TEXT("MJPG"));		
							MJPGFormatAdded = TRUE;
							SendMessage(g_hwndColorSpace, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(OutString));
						}
					} */
					
				}
				//Select Format
				/* GetResolution(STREAM_CAPTURE,&tempResolution,g_CaptureResolutionIndex);
				if(IsEqualGUID(tempResolution.subType, MEDIASUBTYPE_YUY2)) 
				{
					wsprintf(OutString, TEXT("YUY2"));
					
				}
				if(IsEqualGUID(tempResolution.subType, MEDIASUBTYPE_MJPG)) 
				{
					wsprintf(OutString, TEXT("MJPG"));		
				}
				SendMessage(g_hwndColorSpace, CB_SELECTSTRING, 0, reinterpret_cast<LPARAM>(OutString));	 */			
				 
					
				//CB_GETEDITSEL
				RETAILMSG(DEBUG_ENABLE,(TEXT("g_NumofCaptureResolutions = %lu"),g_NumofCaptureResolutions));	
				
				SendMessage(g_hwndCapturePins, CB_SETCURSEL, (WPARAM)g_CaptureResolutionIndex, (LPARAM)0);
				SendMessage(g_hwndCapturePins, CB_SETITEMHEIGHT, (WPARAM)(0), (LPARAM)20);
				

				/* g_hwndStillPins = GetDlgItem(hDlg, IDC_STILLOUTPUT);
				for(int i=0; i<g_NumofStillResolutions; i++)
				{
					GetResolution(STREAM_STILL,&tempResolution,i);
					wsprintf(OutString,L"%dx%d",tempResolution.width,tempResolution.height); 
					SendMessage(g_hwndStillPins, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(OutString));
				}
				SendMessage(g_hwndStillPins, CB_SETCURSEL, (WPARAM)g_StillResolutionIndex, (LPARAM)0);
				SendMessage(g_hwndStillPins, CB_SETITEMHEIGHT, (WPARAM)(0), (LPARAM)20); */

				

				
            }
		}	
        case WM_COMMAND:
            switch ( LOWORD(wParam) )
			{	
				
				case ID_CAPTUREOK:
				{
					UINT8 index;
					//CAMFORMATPROS tempResolution;
					//CAMFORMATPROS SelectResolution;
					//index = (UINT8) SendMessage(g_hwndCapturePins, CB_GETCURSEL, (WPARAM)0, (LPARAM)0);
					//SendMessage(g_hwndColorSpace, CB_GETLBTEXT, index, (LPARAM)SelOutString);
					
					//GetResolution(STREAM_CAPTURE,&tempResolution,index);
					/* if(IsEqualGUID(tempResolution.subType, MEDIASUBTYPE_YUY2)) 
					{
						wsprintf(RunOutString, TEXT("YUY2"));	
							
					}
					if(IsEqualGUID(tempResolution.subType, MEDIASUBTYPE_MJPG)) 
					{
						wsprintf(RunOutString, TEXT("MJPG"));			
					}
					
					if(wcscmp(SelOutString,RunOutString))
					{
						if(SelOutString[0] == 'Y' && SelOutString[1] == 'U'  && SelOutString[2] == 'Y' && SelOutString[3] == '2')
						{
							SelectResolution.subType = MEDIASUBTYPE_YUY2;
						}
						else if(SelOutString[0] == 'M' && SelOutString[1] == 'J'  && SelOutString[2] == 'P' && SelOutString[3] == 'G')
						{
							SelectResolution.subType = MEDIASUBTYPE_MJPG;
						}
					} */

					
					
					HRESULT hr; RECT rc;
					index = (UINT8) SendMessage(g_hwndCapturePins, CB_GETCURSEL, (WPARAM)0, (LPARAM)0);
					CAMFORMATPROS tempResolution2;
					RETAILMSG(DEBUG_ENABLE,(TEXT("Captute Select %d\r\n"),index));

					if((index  != g_CaptureResolutionIndex))
					{				
						GetVideoProfile(STREAM_CAPTURE,index,STREAM_CAPTURE);
						GetVideoProfile(STREAM_STILL,index,STREAM_CAPTURE);
						GetResolution(STREAM_CAPTURE,&tempResolution2,index);
						
						//rc.top = g_MenuBarHeight;
						//rc.left = 0;
						//rc.right = tempResolution2.width;
						//rc.bottom = tempResolution2.height+g_MenuBarHeight;  
						
						//if(rc.right > GetSystemMetrics(SM_CXSCREEN) || rc.bottom > GetSystemMetrics(SM_CYSCREEN))
						//{
						//	//rc.right = GetSystemMetrics(SM_CXSCREEN);
						//	//rc.bottom = GetSystemMetrics(SM_CYSCREEN);
						//	TCHAR debugMsg[MAX_PATH];
						//	wsprintf(debugMsg,L"Configuring Resolution are larger than Monitor resolution(%d x %d )\r\n Configure less than Monitor resolution",GetSystemMetrics(SM_CXSCREEN),GetSystemMetrics(SM_CYSCREEN));
						//	MessageBox(hDlg,debugMsg,L"Error",MB_OK);
						//	EndDialog(hDlg, message);
						//	return ERROR_NOT_SUPPORTED; 
						//}
						
						g_CaptureResolutionIndex = index;
						//For Different Still Resolution index dont update g_StillResolutionIndex
						g_StillResolutionIndex = index;

						g_DShowCaptureGraph.Cleanup();
						
						hr = g_DShowCaptureGraph.SetFormat(STREAM_CAPTURE,g_CurrentVideoProfile);
						if (!SUCCEEDED(hr))
						{
							RETAILMSG(1,(TEXT("SetFormat Fails\r\n")));
						}
						//hr = g_DShowCaptureGraph.SetFormat(STREAM_STILL,g_CurrentVideoProfile);
						hr = g_DShowCaptureGraph.SetFormat(STREAM_STILL,g_CurrentStillProfile);
						if ( !SUCCEEDED(hr))
						{
							RETAILMSG(1,(TEXT("SetFormat Fails\r\n")));
						}
						rc.top = g_MenuBarHeight;
						rc.left = 0;
						rc.right = 0;
						rc.bottom = 0;  
						RETAILMSG(DEBUG_ENABLE,(TEXT("rc.right = %lu, rc.bottom = %lu, rc.top = %lu\r\n"),rc.right,rc.bottom,rc.top));
						if(SUCCEEDED(g_DShowCaptureGraph.Init(g_Hwnd, &rc, g_dwFilters)))
						{                													
							hr = g_DShowCaptureGraph.SetStillCaptureFileName(g_tszStillFileName);
								if(FAILED(hr))
								{
									RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to set the still image file name.")));
								}

								hr = g_DShowCaptureGraph.SetVideoCaptureFileName(g_tszCaptureFileName);
								if(FAILED(hr))
								{
									RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to set the video capture file name.")));
								}
							
							hr = g_DShowCaptureGraph.RunGraph();
							if(FAILED(hr))
							{
								RETAILMSG(1, ( TEXT("CameraDShowApp: Starting the capture graph failed.")));
							}
						}
					}	
					{
						UINT32 stillIndex;
						//stillIndex = (UINT8) SendMessage(g_hwndStillPins, CB_GETCURSEL, (WPARAM)0, (LPARAM)0);
						/* if((stillIndex  != g_StillResolutionIndex))
						{							
							g_StillResolutionIndex = stillIndex;
							RETAILMSG(DEBUG_ENABLE,(TEXT("StillResolutionIndex = %;h"),g_StillResolutionIndex));
						}	*/				
					}
				EndDialog(hDlg, message);
				return TRUE;
				}
			case ID_CAPTURECANCEL:
				EndDialog(hDlg,message);
				return TRUE;
			case ID_CAPTUREAPPLY:
				{
					UINT8 index;
					index = (UINT8) SendMessage(g_hwndCapturePins, CB_GETCURSEL, (WPARAM)0, (LPARAM)0);
					RETAILMSG(DEBUG_ENABLE,(TEXT("Captute Select %d\r\n"),index));
					HRESULT hr; RECT rc;
					
					CAMFORMATPROS tempResolution2;
					if((index  != g_CaptureResolutionIndex))
					{				
						GetVideoProfile(STREAM_CAPTURE,index,STREAM_CAPTURE);
						GetVideoProfile(STREAM_STILL,index,STREAM_CAPTURE);
						GetResolution(STREAM_CAPTURE,&tempResolution2,index);
						
						//rc.top = g_MenuBarHeight;
						//rc.left = 0;
						//rc.right = tempResolution2.width;
						//rc.bottom = tempResolution2.height+g_MenuBarHeight;  
						
						/*if(rc.right > GetSystemMetrics(SM_CXSCREEN) || rc.bottom > GetSystemMetrics(SM_CYSCREEN))
						{
							TCHAR debugMsg[MAX_PATH];
							wsprintf(debugMsg,L"Configuring Resolution are larger than Monitor resolution(%d x %d )\r\n Configure less than Monitor resolution",GetSystemMetrics(SM_CXSCREEN),GetSystemMetrics(SM_CYSCREEN));
							MessageBox(hDlg,debugMsg,L"Error",MB_OK);
							EndDialog(hDlg, message);
							return ERROR_NOT_SUPPORTED;
						}*/
						
						g_CaptureResolutionIndex = index;
						//For Different Still Resolution index dont update g_StillResolutionIndex
						g_StillResolutionIndex  = index;
						g_DShowCaptureGraph.Cleanup();
						
						hr = g_DShowCaptureGraph.SetFormat(STREAM_CAPTURE,g_CurrentVideoProfile);
						if (!SUCCEEDED(hr))
						{
							RETAILMSG(1,(TEXT("SetFormat Fails\r\n")));
						}
						hr = g_DShowCaptureGraph.SetFormat(STREAM_STILL,g_CurrentStillProfile);
						if (!SUCCEEDED(hr))
						{
							RETAILMSG(1,(TEXT("SetFormat Fails\r\n")));
						}

						RETAILMSG(DEBUG_ENABLE,(TEXT("rc.right = %lu, rc.bottom = %lu, rc.top = %lu\r\n"),rc.right,rc.bottom,rc.top));
						
						rc.top = g_MenuBarHeight;
						rc.left = 0;
						rc.right = 0;
						rc.bottom = 0;  

						if(SUCCEEDED(g_DShowCaptureGraph.Init(g_Hwnd, &rc, g_dwFilters)))
						{                													
							hr = g_DShowCaptureGraph.SetStillCaptureFileName(g_tszStillFileName);
							if(FAILED(hr))
							{
								RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to set the still image file name.")));
							}

							hr = g_DShowCaptureGraph.SetVideoCaptureFileName(g_tszCaptureFileName);
							if(FAILED(hr))
							{
								RETAILMSG(1, ( TEXT("CameraDShowApp: Failed to set the video capture file name.")));
							}
							
							hr = g_DShowCaptureGraph.RunGraph();
							if(FAILED(hr))
							{
								RETAILMSG(1, ( TEXT("CameraDShowApp: Starting the capture graph failed.")));
							}
						}
					}
					{
						UINT32 stillIndex;
						stillIndex = (UINT8) SendMessage(g_hwndStillPins, CB_GETCURSEL, (WPARAM)0, (LPARAM)0);
						if((stillIndex  != g_StillResolutionIndex))
						{
							//If you want different still resolution you can use this.
							g_StillResolutionIndex = stillIndex;
							//RETAILMSG(DEBUG_ENABLE,(TEXT("StillResolutionIndex = %;h"),g_StillResolutionIndex));
						}					
					}
				}
				EndDialog(hDlg, message);
				return TRUE;
				break;
			
			}
            break;

        case WM_CLOSE:
            EndDialog(hDlg, message);
            return TRUE;

    }
    return (INT_PTR)FALSE;
}
//
//  FUNCTION: GetResolution(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Get Camera Current Resolution.
//
//
HRESULT GetResolution(int nStream,CAMFORMATPROS *supResolutions,UINT8 index)
{
	HRESULT hr;
	
	VIDEO_STREAM_CONFIG_CAPS scc;
	AM_MEDIA_TYPE *pmtConfig;
	VIDEOINFOHEADER *pVih;
	hr = g_DShowCaptureGraph.GetStreamCaps(nStream,index, &pmtConfig, (BYTE*)&scc);
	if (SUCCEEDED(hr))
	{
			// Examine the format. 			 
		    // since our camera don't support cropping, we use the original output
			pVih = (VIDEOINFOHEADER*)pmtConfig->pbFormat;	
			supResolutions->width  = pVih->bmiHeader.biWidth;
			supResolutions->height = pVih->bmiHeader.biHeight;
			supResolutions->index  = index;
			supResolutions->AvgTimePerFrame = pVih->AvgTimePerFrame;
			supResolutions->subType = 	pmtConfig->subtype;
			
		//if(IsEqualGUID(pmtConfig->subtype, MEDIASUBTYPE_UYVY)) {
		//	_tcscpy(subtype, TEXT("UYVY"));
		//}

			RETAILMSG(DEBUG_ENABLE,(TEXT("supResolutions->index = %d \r\n"),supResolutions->index));
			RETAILMSG(DEBUG_ENABLE,(TEXT("supResolutions->width = %d \r\n"),supResolutions->width));
			RETAILMSG(DEBUG_ENABLE,(TEXT("supResolutions->height = %d \r\n"),supResolutions->height));
			RETAILMSG(DEBUG_ENABLE,(TEXT("supResolutions->AvgTimePerFrame = %d \r\n"),supResolutions->AvgTimePerFrame));
			RETAILMSG(DEBUG_ENABLE,(TEXT("pmtConfig->SubType = 0x%X \r\n"),pmtConfig->subtype));
	}
	return hr;

}
//
//  FUNCTION: FormatSelectDialog(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  It is for to select Application Features 
//
//
INT_PTR CALLBACK FormatSelectDialog(HWND hDlg, unsigned message, LONG wParam, LONG lParam)
{
    HWND    hID;
    BOOL    fRet = FALSE;
    TCHAR **ptszCameraDrivers;
    int nDriverCount;
    int iNum, nPos;

    switch (message) 
    {
        case WM_INITDIALOG:           
            if(FAILED(g_DShowCaptureGraph.GetDriverList(&ptszCameraDrivers, &nDriverCount)))
            {
                RETAILMSG(1, ( TEXT("CameraDShowApp: Retrieving the driver list failed.")));
            }

            // populate the preview combo box
            hID = GetDlgItem(hDlg, IDC_DRIVERSELECT);
            for(iNum = 0; iNum < nDriverCount; iNum++)
            {
                nPos = SendMessage(hID, CB_INSERTSTRING, -1, (LPARAM)ptszCameraDrivers[iNum]);
                SendMessage(hID, CB_SETITEMDATA, nPos, _wtol(ptszCameraDrivers[iNum]));
            }
            SendMessage(hID, CB_SETCURSEL, 0, 0);
            nPos = SendMessage(hID, CB_GETCURSEL, 0, 0);
            if(FAILED(g_DShowCaptureGraph.SelectCameraDevice( nPos )))
            {
                RETAILMSG(1, ( TEXT("CameraDShowApp: Selecting the camera device failed.")));
            }

            // grab and set the file names if they were given, before we close the dialog.
            hID = GetDlgItem(hDlg, IDC_STILLNAME);
            SetWindowText(hID, (LPTSTR)STILL_IMAGE_FILE_NAME);

            hID = GetDlgItem(hDlg, IDC_CAPTURENAME);
            SetWindowText(hID, (LPTSTR)VIDEO_CAPTURE_FILE_NAME);

			hID = GetDlgItem(hDlg, IDC_VCFCHECK);
            SendMessage(hID, BM_SETCHECK, BST_CHECKED, 0);

            hID = GetDlgItem(hDlg, IDC_VRCHECK);
            SendMessage(hID, BM_SETCHECK, BST_CHECKED, 0);

            hID = GetDlgItem(hDlg, IDC_STILLCHECK);
            SendMessage(hID, BM_SETCHECK, BST_CHECKED, 0);

            hID = GetDlgItem(hDlg, IDC_FILEMUXCHECK);
            SendMessage(hID, BM_SETCHECK, BST_CHECKED, 0);

            hID = GetDlgItem(hDlg, IDC_VIDEOENCODER);
            SendMessage(hID, BM_SETCHECK, BST_CHECKED, 0);

            fRet = TRUE;

            g_dwFilters = VIDEO_CAPTURE_FILTER | VIDEO_RENDERER | STILL_IMAGE_SINK | FILE_WRITER | VIDEO_ENCODER;
            break;
        case WM_COMMAND:
            switch(LOWORD(wParam)) 
            {
                case IDC_VCFCHECK:
                    hID = GetDlgItem(hDlg, IDC_VCFCHECK);
                    if(SendMessage(hID, BM_GETCHECK, 0, 0))
                        g_dwFilters |= VIDEO_CAPTURE_FILTER;
                    else
                        g_dwFilters &= ~VIDEO_CAPTURE_FILTER;
                    break;
                case IDC_VRCHECK:
                    hID = GetDlgItem(hDlg, IDC_VRCHECK);
                    if(SendMessage(hID, BM_GETCHECK, 0, 0))
                        g_dwFilters |= VIDEO_RENDERER;
                    else
                        g_dwFilters &= ~VIDEO_RENDERER;
                    break;
                case IDC_STILLCHECK:
                    hID = GetDlgItem(hDlg, IDC_STILLCHECK);
                    if(SendMessage(hID, BM_GETCHECK, 0, 0))
                        g_dwFilters |= STILL_IMAGE_SINK;
                    else
                        g_dwFilters &= ~STILL_IMAGE_SINK;
                    break;
                case IDC_FILEMUXCHECK:
                    hID = GetDlgItem(hDlg, IDC_FILEMUXCHECK);
                    if(SendMessage(hID, BM_GETCHECK, 0, 0))
                        g_dwFilters |= FILE_WRITER;
                    else
                        g_dwFilters &= ~FILE_WRITER;
                    break;
                case IDC_AUDIOCAPTURE:
                    hID = GetDlgItem(hDlg, IDC_AUDIOCAPTURE);
                    if(SendMessage(hID, BM_GETCHECK, 0, 0))
					{
                        gAudioCapture=TRUE;
						g_dwFilters |= AUDIO_CAPTURE_FILTER;
					}
					else
                        g_dwFilters &= ~AUDIO_CAPTURE_FILTER;
                    break;
                case IDC_VIDEOENCODER:
                    hID = GetDlgItem(hDlg, IDC_VIDEOENCODER);
                    if(SendMessage(hID, BM_GETCHECK, 0, 0))
                        g_dwFilters |= VIDEO_ENCODER;
                    else
                        g_dwFilters &= ~VIDEO_ENCODER;
                    break;
                case IDC_AUDIOENCODER:
                    hID = GetDlgItem(hDlg, IDC_AUDIOENCODER);
                    if(SendMessage(hID, BM_GETCHECK, 0, 0))
					{
                        gAudioEncoder=TRUE;
						g_dwFilters |= AUDIO_ENCODER;
					}
					else
                        g_dwFilters &= ~AUDIO_ENCODER;
                    break;
                case IDC_VRINTELLICHECK:
                    hID = GetDlgItem(hDlg, IDC_VRINTELLICHECK);
                    if(SendMessage(hID, BM_GETCHECK, 0, 0))
                        g_dwFilters |= VIDEO_RENDERER_INTELI_CONNECT;
                    else
                        g_dwFilters &= ~VIDEO_RENDERER_INTELI_CONNECT;
                    break;
                case IDC_SIMULTCONTROL:
                    hID = GetDlgItem(hDlg, IDC_SIMULTCONTROL);
                    if(SendMessage(hID, BM_GETCHECK, 0, 0))
                        g_dwFilters |= OPTION_SIMULT_CONTROL;
                    else
                        g_dwFilters &= ~OPTION_SIMULT_CONTROL;
                    break;
                case IDC_DRIVERSELECT:
                    hID = GetDlgItem(hDlg, IDC_DRIVERSELECT);
                    nPos = SendMessage(hID, CB_GETCURSEL, 0, 0);
                    if(FAILED(g_DShowCaptureGraph.SelectCameraDevice( nPos )))
                    {
                        RETAILMSG(1, ( TEXT("CameraDShowApp: Selecting the camera device failed.")));
                    }
                    break;
                case IDC_STILLNAME:
                case IDC_CAPTURENAME:
                    break;
                case IDC_OK:
                    // grab and set the file names if they were given, before we close the dialog.
                    hID = GetDlgItem(hDlg, IDC_STILLNAME);
                    GetWindowText(hID, g_tszStillFileName, MAX_PATH);

                    hID = GetDlgItem(hDlg, IDC_CAPTURENAME);
                    GetWindowText(hID, g_tszCaptureFileName, MAX_PATH);
                    EndDialog(hDlg, TRUE);
                    fRet = TRUE;
                    break;
            }
            break;
        case WM_CLOSE:
            EndDialog(hDlg, TRUE);
            fRet = TRUE;
            break;
        default:
            break;
    }

    return (fRet);
}


//
//  FUNCTION: GetCurrentStillResolution
//
//  PURPOSE: Get current Still Resolution
//
//  COMMENTS:
//
HRESULT GetCurrentStillResolution()
{
	HRESULT hr;
	AM_MEDIA_TYPE *pmtConfig;
	VIDEOINFOHEADER *pVih;
	CAMFORMATPROS currentCapResolution;
	VIDEO_STREAM_CONFIG_CAPS scc;
	hr = g_DShowCaptureGraph.GetFormat(STREAM_STILL,&pmtConfig);

	if (SUCCEEDED(hr))
	{
		pVih = (VIDEOINFOHEADER*)pmtConfig->pbFormat;								
		RETAILMSG(1,(TEXT("Still Width = %d,Height = %d\r\n"),pVih->bmiHeader.biWidth,abs(pVih->bmiHeader.biHeight)));
		currentCapResolution.width = pVih->bmiHeader.biWidth;
		currentCapResolution.height = pVih->bmiHeader.biHeight;
	}

	for (int iFormat = 0; iFormat < g_NumofStillResolutions; iFormat++)
	{
			hr = g_DShowCaptureGraph.GetStreamCaps(STREAM_STILL,iFormat, &pmtConfig, (BYTE*)&scc);
			if (SUCCEEDED(hr))
			{
				// Examine the format. 			 
			    // since our camera don't support cropping, we use the original output
				pVih = (VIDEOINFOHEADER*)pmtConfig->pbFormat;	
				
				if (pVih->bmiHeader.biWidth == currentCapResolution.width && pVih->bmiHeader.biHeight == currentCapResolution.height)
				{
					g_StillResolutionIndex = iFormat;	
					break;
				}
			}

	}
	return hr;
}

//
//  FUNCTION: GetCurrentVideoResolution
//
//  PURPOSE: Get Current Video Resolution
//
//  COMMENTS:
//
HRESULT GetCurrentVideoResolution()
{
	HRESULT hr;
	AM_MEDIA_TYPE *pmtConfig;
	VIDEOINFOHEADER *pVih;
	CAMFORMATPROS curCapResolution;
	VIDEO_STREAM_CONFIG_CAPS scc;
	hr = g_DShowCaptureGraph.GetFormat(STREAM_CAPTURE,&pmtConfig);

	if (SUCCEEDED(hr))
	{
		pVih = (VIDEOINFOHEADER*)pmtConfig->pbFormat;								
		RETAILMSG(1,(TEXT("Video Width = %d,Height = %d\r\n"),pVih->bmiHeader.biWidth,abs(pVih->bmiHeader.biHeight)));
		curCapResolution.width = pVih->bmiHeader.biWidth;
		curCapResolution.height = pVih->bmiHeader.biHeight;
		curCapResolution.subType = pmtConfig->subtype;
		curCapResolution.AvgTimePerFrame = pVih->AvgTimePerFrame;
	}


	for (int iFormat = 0; iFormat < g_NumofCaptureResolutions; iFormat++)
	{
			hr = g_DShowCaptureGraph.GetStreamCaps(STREAM_CAPTURE,iFormat, &pmtConfig, (BYTE*)&scc);
			if (SUCCEEDED(hr))
			{
				// Examine the format. 			 
			    // since our camera don't support cropping, we use the original output
				pVih = (VIDEOINFOHEADER*)pmtConfig->pbFormat;	
				if (pVih->bmiHeader.biWidth == curCapResolution.width && pVih->bmiHeader.biHeight == curCapResolution.height && pVih->AvgTimePerFrame == curCapResolution.AvgTimePerFrame)
				{
					g_CaptureResolutionIndex = iFormat;	
					break;
				}
			}

	}
	return hr;
}
//
//  FUNCTION: GetVideoProfile
//
//  PURPOSE: Get current Video Profile
//
//  COMMENTS:
//
HRESULT GetVideoProfile(int nStream,UINT8 nCurrentRes,UINT8 nIndexType)
{
	HRESULT hr;
	VIDEO_STREAM_CONFIG_CAPS scc;
	AM_MEDIA_TYPE *pmtConfig;
	VIDEOINFOHEADER *pVih;
	VIDEOINFOHEADER *pVihCur;

	if(nIndexType == STREAM_CAPTURE)
	{
		hr = g_DShowCaptureGraph.GetStreamCaps(STREAM_CAPTURE,nCurrentRes, &pmtConfig, (BYTE*)&scc);
	}
	if(nIndexType == STREAM_STILL)
	{
		hr = g_DShowCaptureGraph.GetStreamCaps(STREAM_STILL,nCurrentRes, &pmtConfig, (BYTE*)&scc);
	}

	if (SUCCEEDED(hr))
	{
		// Examine the format. 			 
	    // since our camera don't support cropping, we use the original output
		pVih = (VIDEOINFOHEADER*)pmtConfig->pbFormat;	
		
			if(nStream == STREAM_CAPTURE)
			{
				if(nIndexType == STREAM_STILL)
				{
					for (int iFormat = 0; iFormat < g_NumofCaptureResolutions; iFormat++)
					{
							hr = g_DShowCaptureGraph.GetStreamCaps(STREAM_CAPTURE,iFormat, &g_CurrentVideoProfile, (BYTE*)&scc);
							if (SUCCEEDED(hr))
							{
								pVihCur = (VIDEOINFOHEADER*)g_CurrentVideoProfile->pbFormat	;
								if (pVih->bmiHeader.biWidth == pVihCur->bmiHeader.biWidth && pVih->bmiHeader.biHeight == pVihCur->bmiHeader.biHeight)
								{
									RETAILMSG(1,(TEXT("Found Video Profile %lu,%lu\r\n"),pVihCur->bmiHeader.biWidth,pVihCur->bmiHeader.biHeight));
									break;
								}
							}

					}
				}
				else
				{
					g_DShowCaptureGraph.GetStreamCaps(nStream,nCurrentRes,&g_CurrentVideoProfile, (BYTE*)&scc);
				}
			}
			if(nStream == STREAM_STILL)
			{
				
				if(nIndexType == STREAM_CAPTURE)
				{
					for (int iFormat = 0; iFormat < g_NumofStillResolutions; iFormat++)
					{
							hr = g_DShowCaptureGraph.GetStreamCaps(STREAM_STILL,iFormat, &g_CurrentStillProfile, (BYTE*)&scc);
							if (SUCCEEDED(hr))
							{
								pVihCur = (VIDEOINFOHEADER*)g_CurrentStillProfile->pbFormat	;
								
								if (pVih->bmiHeader.biWidth == pVihCur->bmiHeader.biWidth && pVih->bmiHeader.biHeight == pVihCur->bmiHeader.biHeight)
								{
									RETAILMSG(1,(TEXT("Found Still Profile %lu,%lu\r\n"),pVihCur->bmiHeader.biWidth,pVihCur->bmiHeader.biHeight));
									break;
								}
							}

					}
				}
				else
				{
					g_DShowCaptureGraph.GetStreamCaps(nStream,nCurrentRes,&g_CurrentStillProfile, (BYTE*)&scc);
				}
				
			}
	}
	
	return hr;
}


