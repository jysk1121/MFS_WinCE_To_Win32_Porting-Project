//#include <windows.h>                 // For all that Windows stuff
//#include <stdlib.h>
//#include <stdio.h>
#include "logging.h"
#include "SampleGrabber.h"
#if (_WIN32_WCE == 0x800)
#include "wincodec.h"
#else
#include <imaging.h>
#endif
//#include "struct.h"

#define SCR_WIDHT			640
#define SCR_HEIGHT			240
#define FONT_HEIGHT		55
#define FONT_WIDHT		30

#define CAMERA_PREVIEW_WIDTH	176
#define CAMERA_PREVIEW_HEIGHT	144

DBGPARAM dpCurSettings;

BOOL	firstBitmap	=	TRUE;
HDC		hdc			=	NULL;			// Hold screen Device context 
HDC		memDC		=	NULL;			// CreateCompatibleDC(NULL);
HBITMAP bmp			=	NULL;			// Create bitmap to be used to feed source filter
HBRUSH	brush		=	NULL;			// brush to paint bitmap background
BYTE	*pBuffer	=	NULL;			// buffer to hold bitmap bits in createDIBSection function
static WORD *bitmapDone = NULL;
static DWORD userLoadedBitmapWidht = 0;
static DWORD userLoadedBitmapHeight = 0;
BYTE	*yplane		=	NULL;
BYTE	*uplane		=	NULL;
BYTE	*vplane		=	NULL;
BYTE	*bitmapData =	NULL;
static BYTE *myBuffer		=	NULL;
char dumpFile[256];
int count = 0;
FILE *fDump;

extern HWND g_Hwnd;

DWORD counter = 0;

typedef struct {
	int nHeight;
	int nWidth;
	int PixelFormat;
} BMPFMT, *PBMPFMT;

//IWICImagingFactory

//IWICBitmapDecoder
#if (_WIN32_WCE == 0x800)
IWICImagingFactory *pImagingFactory = NULL;
#else
IImagingFactory *pImagingFactory = NULL;
#endif

CUnknown *WINAPI CSampleGrabber::CreateInstance(LPUNKNOWN punk, HRESULT *phr)
{
	HRESULT hr;
	if (!phr)
		phr = &hr;
	CSampleGrabber *pNewObject = new CSampleGrabber(punk, phr, FALSE);
	if (pNewObject == NULL)
		*phr = E_OUTOFMEMORY;
	return pNewObject;
}

CSampleGrabber::CSampleGrabber(IUnknown * pOuter, HRESULT * phr, BOOL ModifiesData):CTransInPlaceFilter( FILTERNAME, (IUnknown *) pOuter, CLSID_SampleGrabber, phr)
{ 
	HRESULT hr;
	BOOL fFound = FALSE;

	//int nLen = pszExt ? lstrlen (pszExt) : 0; 
	int nLen = 0; 

	createBitmap(640, 50);
	//myBuffer = new myBuffer[640*240 + 640*240];//
	myBuffer =(BYTE *)malloc(640*240 + 640*240);
	if(myBuffer == NULL)
	{
		DETAIL(L"CSampleGrabber <--");	
		return ;
	}
#if (_WIN32_WCE != 0x800)
	if (FAILED(hr = CoInitializeEx(NULL, COINIT_MULTITHREADED)))
    {
        DETAIL(TEXT("CoInitializeEx failed, hr: 0x%08x\r\n"), hr);
        return ;
    }

	 hr = CoCreateInstance(CLSID_ImagingFactory, 
                          NULL, 
                          CLSCTX_INPROC_SERVER, 
                          IID_IImagingFactory, 
                          (void**) &pImagingFactory);
    if (FAILED(hr))
		return;

	//
	// Query current installed codecs
	//
	ImageCodecInfo *pCodecInfo;
	UINT uCnt = 0;
	hr = pImagingFactory->GetInstalledDecoders (&uCnt, &pCodecInfo);
	if (SUCCEEDED(hr))
	{
		DETAIL(TEXT ("Detected %d decoders\r\n"), uCnt);
		for (UINT i = 0; i < uCnt; i++)
		{
			//if (nLen && 
			//	(_wcsnicmp(pCodecInfo[i].FormatDescription, pszExt, nLen) == 0))
			//	fFound = TRUE;
			DETAIL(TEXT("Name  >%S<\r\n"), pCodecInfo[i].CodecName);
			DETAIL(TEXT("Desc  >%S<\r\n\r\n"), pCodecInfo[i].FormatDescription);
		}
		CoTaskMemFree ((PVOID)pCodecInfo);
	}
	
	// See if we were supposed to find specific support and didn't find it
	if (!hr && nLen && !fFound)
	{
		pImagingFactory->Release();
		hr = ERROR_NOT_SUPPORTED;
	}

	writeTextOnBitmap(10, 10, L"Toradex", 20, 20, FALSE, RGB(255,255,255)); 
	convertRGB24toYUV420(640, 50, bitmapDone);
#endif
	callback = NULL;
}

CSampleGrabber::~CSampleGrabber()
{ 
	callback = NULL;
}

HRESULT CSampleGrabber::NonDelegatingQueryInterface(const IID &riid, void **ppv) 
{
	if ( riid == IID_ISampleGrabber )
	{
		return GetInterface(static_cast<ISampleGrabber*>(this), ppv);
	}
	else
		return CTransInPlaceFilter::NonDelegatingQueryInterface(riid, ppv);
}

HRESULT CSampleGrabber::CheckInputType(const CMediaType *pmt)
{
	//NKDbgPrintfW(L"CheckInputType <--");		
	//PrintMediaInfo(pmt);
	/* if((pmt->formattype == FORMAT_VideoInfo)&&( pmt->subtype == MEDIASUBTYPE_YV12) && (pmt->majortype == MEDIATYPE_Video))
	{
		PrintMediaInfo(pmt);
		return S_OK;
	}
	else 
		return E_FAIL; */
	return S_OK;
}

BYTE MJPG2JPGHdr[440] = {
	// JPEG file header
	0xff,0xd8,					// SOI
	0xff,0xe0,					// APP0
	0x00,0x10,					// APP0 Hdr size
	0x4a,0x46,0x49,0x46,0x00,	// ID string
	0x01,0x01,					// Version
	0x00,						// Bits per type
	0x00, 0x00,					// X density
	0x00, 0x00,					// Y density
	0x00,						// X Thumbnail size
	0x00,						// Y Thumbnail size

	 /* JPEG DHT Segment for YCrCb omitted from MJPG data */
	0xFF,0xC4,0x01,0xA2,
	0x00,0x00,0x01,0x05,0x01,0x01,0x01,0x01,0x01,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x01,0x00,0x03,0x01,0x01,0x01,0x01,
	0x01,0x01,0x01,0x01,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,
	0x08,0x09,0x0A,0x0B,0x10,0x00,0x02,0x01,0x03,0x03,0x02,0x04,0x03,0x05,0x05,0x04,0x04,0x00,
	0x00,0x01,0x7D,0x01,0x02,0x03,0x00,0x04,0x11,0x05,0x12,0x21,0x31,0x41,0x06,0x13,0x51,0x61,
	0x07,0x22,0x71,0x14,0x32,0x81,0x91,0xA1,0x08,0x23,0x42,0xB1,0xC1,0x15,0x52,0xD1,0xF0,0x24,
	0x33,0x62,0x72,0x82,0x09,0x0A,0x16,0x17,0x18,0x19,0x1A,0x25,0x26,0x27,0x28,0x29,0x2A,0x34,
	0x35,0x36,0x37,0x38,0x39,0x3A,0x43,0x44,0x45,0x46,0x47,0x48,0x49,0x4A,0x53,0x54,0x55,0x56,
	0x57,0x58,0x59,0x5A,0x63,0x64,0x65,0x66,0x67,0x68,0x69,0x6A,0x73,0x74,0x75,0x76,0x77,0x78,
	0x79,0x7A,0x83,0x84,0x85,0x86,0x87,0x88,0x89,0x8A,0x92,0x93,0x94,0x95,0x96,0x97,0x98,0x99,
	0x9A,0xA2,0xA3,0xA4,0xA5,0xA6,0xA7,0xA8,0xA9,0xAA,0xB2,0xB3,0xB4,0xB5,0xB6,0xB7,0xB8,0xB9,
	0xBA,0xC2,0xC3,0xC4,0xC5,0xC6,0xC7,0xC8,0xC9,0xCA,0xD2,0xD3,0xD4,0xD5,0xD6,0xD7,0xD8,0xD9,
	0xDA,0xE1,0xE2,0xE3,0xE4,0xE5,0xE6,0xE7,0xE8,0xE9,0xEA,0xF1,0xF2,0xF3,0xF4,0xF5,0xF6,0xF7,
	0xF8,0xF9,0xFA,0x11,0x00,0x02,0x01,0x02,0x04,0x04,0x03,0x04,0x07,0x05,0x04,0x04,0x00,0x01,
	0x02,0x77,0x00,0x01,0x02,0x03,0x11,0x04,0x05,0x21,0x31,0x06,0x12,0x41,0x51,0x07,0x61,0x71,
	0x13,0x22,0x32,0x81,0x08,0x14,0x42,0x91,0xA1,0xB1,0xC1,0x09,0x23,0x33,0x52,0xF0,0x15,0x62,
	0x72,0xD1,0x0A,0x16,0x24,0x34,0xE1,0x25,0xF1,0x17,0x18,0x19,0x1A,0x26,0x27,0x28,0x29,0x2A,
	0x35,0x36,0x37,0x38,0x39,0x3A,0x43,0x44,0x45,0x46,0x47,0x48,0x49,0x4A,0x53,0x54,0x55,0x56,
	0x57,0x58,0x59,0x5A,0x63,0x64,0x65,0x66,0x67,0x68,0x69,0x6A,0x73,0x74,0x75,0x76,0x77,0x78,
	0x79,0x7A,0x82,0x83,0x84,0x85,0x86,0x87,0x88,0x89,0x8A,0x92,0x93,0x94,0x95,0x96,0x97,0x98,
	0x99,0x9A,0xA2,0xA3,0xA4,0xA5,0xA6,0xA7,0xA8,0xA9,0xAA,0xB2,0xB3,0xB4,0xB5,0xB6,0xB7,0xB8,
	0xB9,0xBA,0xC2,0xC3,0xC4,0xC5,0xC6,0xC7,0xC8,0xC9,0xCA,0xD2,0xD3,0xD4,0xD5,0xD6,0xD7,0xD8,
	0xD9,0xDA,0xE2,0xE3,0xE4,0xE5,0xE6,0xE7,0xE8,0xE9,0xEA,0xF2,0xF3,0xF4,0xF5,0xF6,0xF7,0xF8,
	0xF9,0xFA
};

#if (_WIN32_WCE != 0x800)
//----------------------------------------------------------------------
// GetBitMapImage 
//
HRESULT GetBitMapImage (PBYTE pData, DWORD dwPreBuff, DWORD dwSize, 
						IBitmapImage **ppBitmapImage, PBMPFMT pbmpfmt)
{
	HRESULT hr;
    IImageSink *pImageSink = NULL;
    IImageDecoder *pImageDecoder = NULL;
    IBitmapImage *pBitmapImage = NULL;
    IStream *pStream = NULL;
    ImageInfo ii;
	LPBYTE pLocal = 0;

	if (pImagingFactory == NULL)
		return E_NOINTERFACE;

	if (*pData == 0)
		return 0;

	int MjpegHdrSize = *(pData+4);
	MjpegHdrSize = MjpegHdrSize << 8;
	MjpegHdrSize += *(pData+5)+4;
	if (MjpegHdrSize > 100)
		return -2;

#if 1
	// Slow way copies the data to a seperate heap allocation.  This seems to be needed for the
	// CreateStreamOnHGlobal method because that method looks at the heap block header to determine
	// the size of the data.
	
	// Data is in big endian format
	pLocal = (LPBYTE)LocalAlloc (LPTR, dwSize+512);
	if (!pLocal)
		return -1;

	memcpy (pLocal, MJPG2JPGHdr, sizeof (MJPG2JPGHdr));
	memcpy (pLocal + sizeof (MJPG2JPGHdr), pData + MjpegHdrSize, dwSize - MjpegHdrSize);

    // Create the stream
    hr = CreateStreamOnHGlobal(pLocal, TRUE, &pStream);
#endif
#if 0

	// This way also copies the data but then uses an custom stream
	// interface to expose the data.
	pLocal = (LPBYTE)LocalAlloc (LPTR, dwSize+512);
	if (!pLocal)
		return -1;

	memcpy (pLocal, MJPG2JPGHdr, sizeof (MJPG2JPGHdr));
	memcpy (pLocal + sizeof (MJPG2JPGHdr), pData + MjpegHdrSize, dwSize - MjpegHdrSize);

    // Create the stream
	FrameStream *pfs = new FrameStream (pLocal, dwSize + 512);
	hr = pfs->QueryInterface (__uuidof(IStream)/*IID_IStream*/, (void **)&pStream);
#endif
#if 0
	// Add JPEG header to MJPEG frame data.  We need to also remove the MJPEG info at the start of the frame
	// Data is in big endian format.

	// Expose the data in custom stream interface.

	PBYTE pPreBuff = pData + MjpegHdrSize - sizeof (MJPG2JPGHdr);
	memcpy (pPreBuff, MJPG2JPGHdr, sizeof (MJPG2JPGHdr));

	FrameStream *pfs = new FrameStream (pPreBuff, dwSize + sizeof (MJPG2JPGHdr) - MjpegHdrSize);
	hr = pfs->QueryInterface (__uuidof(IStream)/*IID_IStream*/, (void **)&pStream);
#endif
	__try 
	{
		if (FAILED(hr))
		{
			DETAIL(TEXT("Create stream failed, hr: 0x%08x\r\n"), hr);
			goto finish;
		}

		// Get the decoder.  The system chooses the proper decoder
		// from the format of the data in the buffer.
		if (FAILED(hr = pImagingFactory->CreateImageDecoder(pStream, DecoderInitFlagBuiltIn1st, &pImageDecoder)))
		{
			DETAIL(TEXT("CreateImageDecoder failed, hr: 0x%08x\r\n"), hr);
			goto finish;
		}

		// Query image info
		if (FAILED(hr = pImageDecoder->GetImageInfo(&ii)))
		{
			DETAIL(TEXT("GetImageInfo failed, hr: 0x%08x\r\n"), hr);
			goto finish;
		}

		// Save the width and height
		pbmpfmt->nHeight = ii.Height;
		pbmpfmt->nWidth = ii.Width;
		pbmpfmt->PixelFormat = ii.PixelFormat;

		// Create bitmap of the same size
		if (FAILED(hr = pImagingFactory->CreateNewBitmap(ii.Width, ii.Height, ii.PixelFormat, &pBitmapImage)))
		{
			DETAIL(TEXT("CreateNewBitmap failed, hr = 0x%08x\r\n"), hr);
			goto finish;
		}

		// Get the "sink" which is needed by the decoder so it can write the data to the bitmap
		if (FAILED(hr = pBitmapImage->QueryInterface(IID_IImageSink, (void**)&pImageSink)))
		{
			DETAIL(TEXT("QueryInterface for ImageSink from BitmapImage failed, hr: 0x%08x\r\n"), hr);
			goto finish;
		}

		// Finally, start the conversion
		if (FAILED(hr = pImageDecoder->BeginDecode(pImageSink, NULL)))
		{
			DETAIL(TEXT("BeginDecode into Bitmap Image failed, hr = 0x%08d\r\n"), hr);
			goto finish;
		}

		// Loop as necessary
		while (E_PENDING == (hr = pImageDecoder->Decode()))
			Sleep(100);

		if (hr != S_OK)
		{
			DEBUGCHK ((TEXT("Bad decode hr = %08x\r\n"), hr));
		}
		// Clean up
		hr = pImageDecoder->EndDecode(hr);

		if (FAILED(hr))
		{
			DETAIL (TEXT("Decoding failed, hr = 0x%08x\r\n"), hr);
			// If fail to decode, release block
			if (pLocal)
				LocalFree (pLocal);  
			goto finish;
		}
		DETAIL(TEXT("img size %d\r\n"), dwSize);

	}
	__except (EXCEPTION_EXECUTE_HANDLER) 
	{
		DETAIL(TEXT ("Exception decoding image \r\n"));
	}
finish:
	if (pImageSink)
		pImageSink->Release();
	pImageSink = NULL;

    if (pImageSink)
        pImageSink->Release();
	pImageSink = NULL;

    if (pImageDecoder)
        pImageDecoder->Release();
	pImageDecoder = NULL;
        
    if (pStream)
        pStream->Release();
	pStream = NULL;

	if (!FAILED(hr))
		*ppBitmapImage = pBitmapImage;
	return hr;
}
#endif
//----------------------------------------------------------------------
// DisplayFrame 
//
HRESULT DisplayFrame (PBYTE pData, DWORD dwPreBuff, DWORD dwSize, HDC hdc, RECT *pRect)
{
	HRESULT hr = S_OK;
#if (_WIN32_WCE != 0x800)
    IImage *pImage = NULL;
    IBitmapImage *pBitmapImage = NULL;
	BMPFMT bmpf;

	hr = GetBitMapImage (pData, dwPreBuff, dwSize, &pBitmapImage, &bmpf);
	__try 
	{
		if (SUCCEEDED(hr))
		{
			//
			// We have a bitmap at this point.  Get Image interface and draw
			//
			if (SUCCEEDED(hr = pBitmapImage->QueryInterface(IID_IImage, (void**)&pImage)))
			{
				hr = pImage->Draw (hdc, pRect, NULL);
				//NKDbgPrintfW(L"pImage->Draw");
			}
			else
				DETAIL(TEXT("QueryInterface for Image from BitmapImage failed, hr: 0x%08x\r\n"), hr);
		}
		else
			DETAIL(TEXT("Decoding failed, hr = 0x%08x\r\n"), hr);
	}
	__except (EXCEPTION_EXECUTE_HANDLER) 
	{
		DETAIL(TEXT("Exception decoding image \r\n"));
	}
	if (pImage)
		pImage->Release();
	pImage = NULL;  // This is already deleted above, but just to make sure...

    if (pBitmapImage)
        pBitmapImage->Release();
	pBitmapImage = NULL;
#endif
	return hr;
}

HRESULT CSampleGrabber::Transform(IMediaSample *pMediaSample)
{
	HRESULT			hr					=	S_OK;
	DWORD			Size				=	0;
	BYTE			*pData;
	BYTE			*pdata[3]			=	{NULL};
	DWORD			uOffset				=	0;
	DWORD			vOffset				=	0;
	DWORD			BuffCount			=	3;
	//INvMediaSample	*pNvSample			=	NULL;
	AM_MEDIA_TYPE	InputPinMediaType	=	{0};
	VIDEOINFOHEADER *pVideoInfo			=	{0};
	IMemAllocator	*pMemAllocator		=	NULL;
	ALLOCATOR_PROPERTIES AllocatorProps =	{0};
	DWORD			PitchY				=	0;
	DWORD			PitchUV				=	0;
	DWORD			totalSize			=	0;
	BYTE			*pInData			=	NULL;
	LPBYTE pLocal = 0;

	static DWORD lastTime = 0;
	if(!pMediaSample)
		return E_FAIL;
	//Get pointer to the video buffer data
	if(FAILED(pMediaSample->GetPointer(&pData))) 
		return E_FAIL;
	//Size = pMediaSample->GetSize();
	Size = pMediaSample->GetActualDataLength();
	//uOffset = 640 * 240;
	//vOffset = uOffset * 1.25;

	//pData+=uOffset;
	//if(counter == 4)
	//{
		//DWORD height = 0;
		//for(height = 0; height < 1; height++);
		//{
		//	for(DWORD widht = 0; widht < 640; widht++)
		//	{
		//		pData[height *640 + widht] = rand()%255;
		//	}
		//}
		//pData+=640*100;
		//memset(pData, 255, 640);
		//NKDbgPrintfW(L"Frame:");

	

		DETAIL(L"pData %#08x %lu\n",pData,Size);
		//if((count % ) == 0)
		if(1)
		{
			/* int MjpegHdrSize = *(pData+4);
			MjpegHdrSize = MjpegHdrSize << 8;
			MjpegHdrSize += *(pData+5)+4;
			if (MjpegHdrSize > 100)
				return -2;

			pLocal = (LPBYTE)LocalAlloc (LPTR, Size+512);
			if (!pLocal)
				return -1;

			memcpy (pLocal, MJPG2JPGHdr, sizeof (MJPG2JPGHdr));
			memcpy (pLocal + sizeof (MJPG2JPGHdr), pData + MjpegHdrSize, Size - MjpegHdrSize);

			 // Create the stream
			hr = CreateStreamOnHGlobal(pLocal, TRUE, &pStream);
			
			__try 
			{
				if (FAILED(hr))
				{
					DETAIL(TEXT("Create stream failed, hr: 0x%08x\r\n"), hr);
					goto finish;
				}

				// Get the decoder.  The system chooses the proper decoder
				// from the format of the data in the buffer.
				if (FAILED(hr = pImagingFactory->CreateImageDecoder(pStream, DecoderInitFlagBuiltIn1st, &pImageDecoder)))
				{
					DETAIL(TEXT("CreateImageDecoder failed, hr: 0x%08x\r\n"), hr);
					goto finish;
				}

				// Query image info
				if (FAILED(hr = pImageDecoder->GetImageInfo(&ii)))
				{
					DETAIL(TEXT("GetImageInfo failed, hr: 0x%08x\r\n"), hr);
					goto finish;
				}

				// Save the width and height
				pbmpfmt->nHeight = ii.Height;
				pbmpfmt->nWidth = ii.Width;
				pbmpfmt->PixelFormat = ii.PixelFormat;

				// Create bitmap of the same size
				if (FAILED(hr = pImagingFactory->CreateNewBitmap(ii.Width, ii.Height, ii.PixelFormat, &pBitmapImage)))
				{
					DETAIL(TEXT("CreateNewBitmap failed, hr = 0x%08x\r\n"), hr);
					goto finish;
				}

				// Get the "sink" which is needed by the decoder so it can write the data to the bitmap
				if (FAILED(hr = pBitmapImage->QueryInterface(IID_IImageSink, (void**)&pImageSink)))
				{
					DETAIL(TEXT("QueryInterface for ImageSink from BitmapImage failed, hr: 0x%08x\r\n"), hr);
					goto finish;
				}

				// Finally, start the conversion
				if (FAILED(hr = pImageDecoder->BeginDecode(pImageSink, NULL)))
				{
					DETAIL(TEXT("BeginDecode into Bitmap Image failed, hr = 0x%08d\r\n"), hr));
					goto finish;
				}

				// Loop as necessary
				while (E_PENDING == (hr = pImageDecoder->Decode()))
					Sleep(100);

				if (hr != S_OK)
				{
					DEBUGCHK ((TEXT("Bad decode hr = %08x\r\n"), hr));
				}
				// Clean up
				hr = pImageDecoder->EndDecode(hr);

				if (FAILED(hr))
				{
					DETAIL(TEXT("Decoding failed, hr = 0x%08x\r\n"), hr);
					// If fail to decode, release block
					if (pLocal)
						LocalFree (pLocal);  
					goto finish;
				}
				DETAIL(TEXT("img size %d\r\n"), dwSize);

			}
			__except (EXCEPTION_EXECUTE_HANDLER) 
			{
				DETAIL(TEXT ("Exception decoding image \r\n"));
			}
            */
			RECT rect;
			rect.left = 0;
			rect.top = 0;
			rect.right = CAMERA_PREVIEW_WIDTH;
			rect.bottom = CAMERA_PREVIEW_HEIGHT;
			HDC hdcMain;
			hdcMain = GetDC (g_Hwnd);

			DisplayFrame (pData, 512,Size,hdcMain, &rect);

			//DisplayFrame();
			//sprintf(dumpFile,"dumpFile%d.jpg",count);
			//fDump = fopen(dumpFile,"w+");
			
			//fwrite(pData,Size,1,fDump);
			//fclose(fDump);
			//LocalFree(pLocal);
			
		}
		count++;
		//counter = 0;
	//}
	//NKDbgPrintfW(L"pData %#08x\n",pData);
	counter++;
	//hr = pMediaSample->QueryInterface(IID_INvMediaSample, (void **)&pNvSample);// QueryInterface for INvMediaSample from the received IMediaSample.
	//
	////get the size and virtual addresse to surface present in the attached harware buffer.
	//hr = pNvSample->GetSizes(size, &BuffCount);
	//hr = pNvSample->GetPointers(pdata, &BuffCount);
	//   (void)pNvSample->Release();
	//   pNvSample = NULL;

	//   // Find out the input media type to determine width and height.
	//   hr = m_pInput->ConnectionMediaType(&InputPinMediaType);
	//   pVideoInfo = (VIDEOINFOHEADER *)InputPinMediaType.pbFormat;

	//   // Get allocator properties to determine alignment. Y surface alignment
	//   // is 32 bytes and U, V surface alignment is 32 / 2 = 16 bytes.
	//   hr = m_pInput->GetAllocator(&pMemAllocator);
	//   hr = pMemAllocator->GetProperties(&AllocatorProps);
	//   pMemAllocator->Release();

	//// Calculate the pitch based on width and alignment.
	//   PitchY = GetPitch(pVideoInfo->bmiHeader.biWidth, AllocatorProps.cbAlign);
	//   PitchUV = PitchY / 2;

	// Compute the total size of YUV buffer.
	//   totalSize = (3 * pVideoInfo->bmiHeader.biHeight * pVideoInfo->bmiHeader.biWidth) / 2;
	//pInData = (BYTE *)malloc(totalSize);

	//   // Get the width and height of Y surface and write it to a buffer.
	//   DWORD HeightY = pVideoInfo->bmiHeader.biHeight;
	//   DWORD WidthY = pVideoInfo->bmiHeader.biWidth;

	//   BYTE *pData0 = pdata[0];
	//int index = 0;
	//  for (DWORD Height = 0; Height < HeightY; Height++)
	//  {
	//for(DWORD w = 0; w < WidthY; w++)
	//{
	// pData0[index] = yplane[index];
	// index++;
	//}
	//  }

	//  // Get the width and height of U and V surfaces and write them to
	//  // the same buffer.
	//  DWORD HeightUV = HeightY/4 ;
	//  DWORD WidthUV = WidthY ;

	//  BYTE *pData1 = pdata[1];
	//  for (DWORD Height = 0; Height < HeightUV; Height++)
	//  {
	//for(DWORD w = 0; w < WidthUV; w++)
	//{
	// pData1[w*Height] = uplane[w*Height];
	//}
	//  }

	//  BYTE *pData2 = pdata[2];
	//  for (DWORD Height = 0; Height < HeightUV; Height++)
	//  {
	//for(DWORD w = 0; w < WidthUV; w++)
	//{
	// pData2[w*Height] = vplane[w*Height];
	//}
	//  }
	if(callback)
		callback(pData, Size, m_Height, m_Width, m_Stride);
	return S_OK;
}

DWORD CSampleGrabber::GetPitch(DWORD width, DWORD alignment)
{
	DWORD r = width % alignment;
	return width + r;
}

//HRESULT CSampleGrabber::SetMediaType(PIN_DIRECTION direction, const CMediaType *pmt)
//	{
//	HRESULT hr = S_OK;
//	VIDEOINFOHEADER* vih = (VIDEOINFOHEADER *) pmt->pbFormat;
//	if((pmt->formattype == FORMAT_VideoInfo))
//		{
//		// calculate the stride for RGB formats
//		DWORD dwStride = (vih->bmiHeader.biWidth * (vih->bmiHeader.biBitCount / 8) + 3) & ~3;
//		// set video parameters
//		m_Width = vih->bmiHeader.biWidth;
//		m_Height = vih->bmiHeader.biHeight;
//		m_SampleSize = pmt->lSampleSize;
//		m_Stride = (long)dwStride;
//		}
//	else hr = E_FAIL;
//
//	return hr;
//	}
HRESULT CSampleGrabber::DecideBufferSize(IMemAllocator *pAlloc, ALLOCATOR_PROPERTIES *pProperties)
{
	if (m_pInput->IsConnected() == FALSE) {
		return E_UNEXPECTED;
	}

	ASSERT(pAlloc);
	ASSERT(pProperties);
	HRESULT hr = NOERROR;

	pProperties->cBuffers = 1;
	pProperties->cbBuffer = m_pInput->CurrentMediaType().GetSampleSize();
	ASSERT(pProperties->cbBuffer);

	// Ask the allocator to reserve us some sample memory, NOTE the function
	// can succeed (that is return NOERROR) but still not have allocated the
	// memory that we requested, so we must check we got whatever we wanted
	ALLOCATOR_PROPERTIES Actual;
	hr = pAlloc->SetProperties(pProperties,&Actual);
	if (FAILED(hr)) {
		return hr;
	}

	ASSERT( Actual.cBuffers >= 1 );

	if (pProperties->cBuffers > Actual.cBuffers ||
		pProperties->cbBuffer > Actual.cbBuffer) {
			return E_FAIL;
	}
	return NOERROR;
}

HRESULT CSampleGrabber::GetMediaType(int iPosition, CMediaType *pMediaType)
{
	// Is the input pin connected
	if (m_pInput->IsConnected() == FALSE) {
		return E_UNEXPECTED;
	}

	// This should never happen
	if (iPosition < 0) {
		return E_INVALIDARG;
	}

	// Do we have more items to offer
	if (iPosition > 0) {
		PrintMediaInfo(pMediaType);
		return VFW_S_NO_MORE_ITEMS;
	}

	*pMediaType = m_pInput->CurrentMediaType();
	return NOERROR;
}

//HRESULT CSampleGrabber::Receive(IMediaSample *pSample)
//{
//if(pSample)
//printf("Recie\n");
//	return S_OK;
//}

/////////////////////// ISampleGrabber //////////////////////////
HRESULT CSampleGrabber::SetMediaType(PIN_DIRECTION direction, const CMediaType *pmt)
{
	if(direction == PINDIR_INPUT)
	{
		//NKDbgPrintfW(L"INPUT_PIN_MEDIA:");
		PrintMediaInfo(pmt);
	}
	if(direction == PINDIR_OUTPUT)
	{
		//NKDbgPrintfW(L"OUTPUT_PIN_MEDIA:");
		PrintMediaInfo(pmt);
	}
	return S_OK;
}

STDMETHODIMP CSampleGrabber::RegisterCallback( MANAGED_SAMPLEPROCESSEDPROC mdelegate ) 
{
	// Set pointer to managed delegate
	callback = mdelegate;
	//NKDbgPrintfW(L"RegisterCallback\n");
	return S_OK;
}

//Debug helper Function
void CSampleGrabber::PrintMediaInfo(const CMediaType *pmt)
{
	if(pmt==NULL)
	{
		DETAIL(L"MEDIASUBTYPE_0000000000");
		return; 
	}

	if(pmt->majortype == MEDIATYPE_Video)
		DETAIL(L"Vid:");
	if (pmt->majortype == MEDIATYPE_NvVideo)
		DETAIL(L"NVVid:");
	if(pmt->majortype == MEDIATYPE_NvVideoBuffered)
		DETAIL(L"NVVid:");
	if(pmt->subtype == MEDIASUBTYPE_YV12)
		DETAIL(L"MEDIASUBTYPE_YV12");
	else if (pmt->subtype == MEDIASUBTYPE_RGB565)
		DETAIL(L"MEDIASUBTYPE_RGB565");
	else if (pmt->subtype == MEDIATYPE_NvVideoBuffered)
		DETAIL(L"MEDIATYPE_NvVideoBuffered");
	else if (pmt->subtype == MEDIASUBTYPE_NvI420)
		DETAIL(L"MEDIASUBTYPE_NvI420");
	else if (pmt->subtype == MEDIASUBTYPE_NvYUV420)
		DETAIL(L"MEDIASUBTYPE_NvYUV420");
	else if (pmt->subtype == MEDIASUBTYPE_NvMMBuffer)
		DETAIL(L"MEDIASUBTYPE_NvMMBuffer");
	else if (pmt->subtype == MEDIASUBTYPE_Bayer)
		DETAIL(L"MEDIASUBTYPE_Bayer");
	else
		//DETAIL(L"MEDIASUBTYPE_Unknown");

	if( pmt->pbFormat==NULL)
		return;

	VIDEOINFOHEADER *pVideoInfo = (VIDEOINFOHEADER *)pmt->pbFormat;
	/* NKDbgPrintfW(L": w:%d h:%d sr:%d,%d,%d,%d tr:%d,%d,%d,%d bpp:%d\n",
		pVideoInfo->bmiHeader.biWidth,
		pVideoInfo->bmiHeader.biHeight,
		pVideoInfo->rcSource.left,pVideoInfo->rcSource.top,pVideoInfo->rcSource.right,pVideoInfo->rcSource.bottom,
		pVideoInfo->rcTarget.left,pVideoInfo->rcTarget.top,pVideoInfo->rcTarget.right,pVideoInfo->rcSource.bottom,
		pVideoInfo->bmiHeader.biBitCount); */

}

BOOL createBitmap(DWORD widht, DWORD height)
{
	BOOL retVal = TRUE;
	BITMAPINFO bmpInfo;
	DWORD bmpWidth = widht;
	DWORD bmpHeight = height;

	memset(&bmpInfo, 0, sizeof(BITMAPINFO));
	bmpInfo.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmpInfo.bmiHeader.biWidth = bmpWidth;
	bmpInfo.bmiHeader.biHeight = -bmpHeight;						// to avoid bottom up problem of DIB bitmap
	bmpInfo.bmiHeader.biBitCount = 24;								// no of bits used to create one pixel
	bmpInfo.bmiHeader.biCompression = BI_RGB;
	bmpInfo.bmiHeader.biPlanes = 1;
	bmpInfo.bmiHeader.biSizeImage = 0;
	bmpInfo.bmiHeader.biXPelsPerMeter = 0x0EC4;
	bmpInfo.bmiHeader.biYPelsPerMeter = 0x0EC4;
	bmpInfo.bmiHeader.biClrUsed = 0;
	bmpInfo.bmiHeader.biClrImportant = 0;

	//DC to current screen
	hdc = GetDC(0);
	if(hdc == NULL)
	{
		printf("Error GetDC(0) %d\r\n", GetLastError());
		return FALSE;
	}
	//in memory DC
	memDC = CreateCompatibleDC(NULL);
	if(memDC == NULL)
	{
		printf("Error CreateCompatibleDC(0) %d\r\n", GetLastError());
		DeleteDC(memDC);
		ReleaseDC(NULL, hdc);
		return FALSE;
	}
	// create bitmap
	bmp = CreateDIBSection(hdc, &bmpInfo, DIB_RGB_COLORS, (void **)&pBuffer, NULL, NULL);
	if(bmp == NULL)
	{
		printf("Error CreateDIBSection(0) %d\r\n", GetLastError());
		DeleteDC(memDC);
		ReleaseDC(NULL, hdc);
		return FALSE;
	}
	// create background brush
	brush = CreateSolidBrush(RGB(0, 0, 0));
	if(brush == NULL)
	{
		printf("Error creating backgroung brush %d\r\n", GetLastError());
		DeleteDC(memDC);
		ReleaseDC(NULL, hdc);
		DeleteBrush(brush);
		return FALSE;
	}
	return 0;
}

BOOL writeTextOnBitmap(DWORD x, DWORD y, LPCTSTR stringToDisplay, DWORD fontHeight, DWORD fontWidht, BOOL eraseScreen, COLORREF color)
{
	HFONT hFont = NULL;
	LOGFONT font ;
	// font properties 
	memset(&font, 0, sizeof(LOGFONT));
	font.lfHeight = fontHeight;
	font.lfWidth = fontWidht;
	font.lfCharSet = DEFAULT_CHARSET;
	font.lfEscapement = 0;
	font.lfOrientation = 0;
	font.lfItalic = FALSE;
	font.lfUnderline = FALSE;
	font.lfStrikeOut = FALSE;
	font.lfQuality = DEFAULT_QUALITY;
	font.lfOutPrecision = OUT_DEFAULT_PRECIS;
	font.lfClipPrecision = CLIP_DEFAULT_PRECIS;
	font.lfPitchAndFamily  = DEFAULT_PITCH |FF_DONTCARE;
	font.lfWeight = FW_BOLD;
	//  _tcsncpy (font.lfFaceName, TEXT("Courier New"), LF_FACESIZE);
	//font.lfFaceName[LF_FACESIZE-1] = TEXT('\0');  // Ensure null termination

	//select bitmap to memory dc
	HBITMAP old_bmp = (HBITMAP)SelectObject(memDC, bmp);		// select created bitmap in memory device context
	SelectObject(memDC, brush);									// select created brush in memory device context
	if(eraseScreen == TRUE)
	{
		Rectangle(memDC, 0, 0, SCR_WIDHT, SCR_HEIGHT);					// paint background with selected brush color
	}
	hFont = CreateFontIndirect(&font);							// create font 
	if(hFont == NULL)
	{
		printf("Error creating font\r\n");
		return FALSE;
	}	
	if(stringToDisplay != NULL)
	{
		HFONT pFont = (HFONT)SelectObject(memDC, hFont);			// select font in to memory device context
		SetTextColor (memDC, color);								// set text color according to RGB data
		SetBkMode(memDC, TRANSPARENT);								// set background mode TRANSPARENT
		// Draw text to the memory DC 
		ExtTextOut(memDC, x, y, NULL, NULL, stringToDisplay, wcslen(stringToDisplay), NULL);
		//previousStringDisplayed = stringToDisplay;
		return TRUE;
	}
	return FALSE;
}

// This function load a bitmap from specified file and convert the
// bitmap to yuv format format.
// Out : bitmapDone is output yplane , uplane, vplane  buffer
// widht of bitmap loaded
// height of bitmap loaeded
DWORD loadUserBitmap(BYTE **y, BYTE **u, BYTE **v)
{
	BITMAPINFOHEADER	infoheader;
	DWORD				heightIndex =	0;
	//BYTE				*bitmapData =	NULL;
	FILE				*bitmapFile =	NULL;
	BYTE				red			=	NULL;
	BYTE				green		=	NULL;;
	BYTE				blue		=	NULL;;
	DWORD				nSize		=	0;
	DWORD byteRead = 0;
	bitmapFile = fopen("\\BMP\\IMAGE_1.bmp", "rb");
	if(bitmapFile == NULL)
	{
		printf("Error opening bitmap file %d\r\n", GetLastError());
		fclose(bitmapFile);
		return -1;
	}
	if(fseek(bitmapFile, sizeof(BITMAPFILEHEADER), SEEK_SET) == 0)
		fread(&infoheader, sizeof(BITMAPINFOHEADER), 1, bitmapFile);
	userLoadedBitmapWidht = infoheader.biWidth;
	userLoadedBitmapHeight = infoheader.biHeight;
	nSize = infoheader.biSizeImage;
	if( 0 == nSize )
	{
		nSize = infoheader.biWidth * infoheader.biHeight * infoheader.biBitCount /8;
	}
	bitmapData = new BYTE[nSize];
	yplane = new BYTE[nSize];
	vplane = new BYTE[nSize];
	uplane = new BYTE[nSize];
	ZeroMemory(bitmapData, nSize);
	ZeroMemory(yplane, nSize);
	ZeroMemory(vplane, nSize);
	ZeroMemory(uplane, nSize);
	int yPos = 0;
	int uPos = 0;
	int vPos = 0;
	for( int y=0; y<infoheader.biHeight; ++y)
	{
		for( int x=0; x<infoheader.biWidth; ++x)
		{
			fread(&blue, sizeof(BYTE), 1, bitmapFile);
			fread(&green, sizeof(BYTE), 1, bitmapFile);
			fread(&red, sizeof(BYTE), 1, bitmapFile);
			//bitmapData[y*infoheader.biWidth + x] = RGB16(red, green, blue);
			yplane[yPos] =  0.299*red + 0.587*green + 0.114*blue;
			uplane[uPos] = -0.147*red - 0.289*green + 0.436*blue;
			vplane[vPos] =  0.615*red - 0.515*green - 0.100*blue;
			yPos++;
			uPos++;
			vPos++;
		}
	}
	return 0;
}

//This function convert 24 bit raw data to YUV420 raw rgb data
// @Out: raw 16 bit buffer
// @In: widht : widht of bitmap used in CreateDIBSection function
// @In: height : height of bitmap used in CreateDIBSection function
BOOL convertRGB24toYUV420(DWORD widht, DWORD height, WORD *bitmapDone)
{
	BYTE	red		= NULL;
	BYTE	green	= NULL;
	BYTE	blue	= NULL;
	DWORD	inc24   = 0;
	DWORD	yPos	= 0;
	DWORD	uPos	= 0;
	DWORD	vPos	= 0;

	//allocate memory for buffer to hold data
	yplane = new BYTE[widht * height];
	vplane = new BYTE[widht * height];
	uplane = new BYTE[widht * height];
	//zero memory
	ZeroMemory(yplane, widht * height);
	ZeroMemory(vplane, widht * height);
	ZeroMemory(uplane, widht * height);

	//convert RGB24 bit format to YUV different buffer
	for( int y=0; y<height; ++y)
	{
		for( int x=0; x<widht; ++x, inc24+=3)
		{
			blue			=	pBuffer[inc24];
			green			=	pBuffer[inc24+1];
			red				=	pBuffer[inc24+2];

			yplane[yPos]	=	0.299*red + 0.587*green + 0.114*blue;
			uplane[uPos]	=	-0.147*red - 0.289*green + 0.436*blue;
			vplane[vPos]	=	0.615*red - 0.515*green - 0.100*blue;
			yPos++;
			uPos++;
			vPos++;
		}
	}
	//solve upside down 
	//for( int y=height-1;  y>=0; --y)
	//{
	//	for( int x=0; x<widht; ++x)
	//		bitmapDone[heightIndex*widht + x] = bitmapData[y*widht + x];
	//	++heightIndex;
	//}
	//free(bitmapData);
	return TRUE;
}