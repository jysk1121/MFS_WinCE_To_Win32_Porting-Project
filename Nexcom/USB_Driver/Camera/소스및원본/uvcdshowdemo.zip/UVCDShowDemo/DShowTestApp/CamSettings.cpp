#include <windows.h>
#include <commctrl.h>
#include "enumdef.h"
#include "resource.h"
#include "CamSettings.h"
#include "captureframework.h"
#include "CamSettings.h"

HINSTANCE g_hInst;



HRESULT GetCurrentStillResolution();
HRESULT GetCurrentVideoResolution();

DWORD dwStartTimeout,dwEndTimeout;

extern CCaptureFramework g_DShowCaptureGraph;
extern  HWND g_Hwnd;
extern DWORD g_dwFilters;
extern TCHAR g_tszStillFileName[MAX_PATH];
extern TCHAR g_tszCaptureFileName[MAX_PATH] ;

HRESULT hr;
//
//  FUNCTION: GetCurrentStillResolution
//
//  PURPOSE: Get current Still Resolution
//
//  COMMENTS:
//
HRESULT GetCurrentStillResolution()
{
	HRESULT hr;
	AM_MEDIA_TYPE *pmtConfig;
	VIDEOINFOHEADER *pVih;
	CAMFORMATPROS currentCapResolution;
	VIDEO_STREAM_CONFIG_CAPS scc;
	hr = g_DShowCaptureGraph.GetFormat(STREAM_STILL,&pmtConfig);

	if (SUCCEEDED(hr))
	{
		pVih = (VIDEOINFOHEADER*)pmtConfig->pbFormat;								
		RETAILMSG(1,(TEXT("Video Width = %d,Height = %d\r\n"),pVih->bmiHeader.biWidth,abs(pVih->bmiHeader.biHeight)));
		currentCapResolution.width = pVih->bmiHeader.biWidth;
		currentCapResolution.height = pVih->bmiHeader.biHeight;
	}
	int iCount = 0, iSize = 0;
	for (int iFormat = 0; iFormat < iCount; iFormat++)
	{
			hr = g_DShowCaptureGraph.GetStreamCaps(STREAM_STILL,iFormat, &pmtConfig, (BYTE*)&scc);
			if (SUCCEEDED(hr))
			{
				// Examine the format. 			 
			    // since our camera don't support cropping, we use the original output
				pVih = (VIDEOINFOHEADER*)pmtConfig->pbFormat;	
				RETAILMSG(1,(TEXT("pVih->bmiHeader.biWidth = %lu***********\r\n"),pVih->bmiHeader.biWidth));
				if (pVih->bmiHeader.biWidth == currentCapResolution.width && pVih->bmiHeader.biHeight == currentCapResolution.height)
				{
					g_StillResolutionIndex = iFormat;													
				}
			}

	}
	return hr;
}

//
//  FUNCTION: GetCurrentVideoResolution
//
//  PURPOSE: Get Current Video Resolution
//
//  COMMENTS:
//
HRESULT GetCurrentVideoResolution()
{
	HRESULT hr;
	AM_MEDIA_TYPE *pmtConfig;
	VIDEOINFOHEADER *pVih;
	CAMFORMATPROS curCapResolution;
	VIDEO_STREAM_CONFIG_CAPS scc;
	hr = g_DShowCaptureGraph.GetFormat(STREAM_CAPTURE,&pmtConfig);

	if (SUCCEEDED(hr))
	{
		pVih = (VIDEOINFOHEADER*)pmtConfig->pbFormat;								
		RETAILMSG(1,(TEXT("Video Width = %d,Height = %d\r\n"),pVih->bmiHeader.biWidth,abs(pVih->bmiHeader.biHeight)));
		curCapResolution.width = pVih->bmiHeader.biWidth;
		curCapResolution.height = pVih->bmiHeader.biHeight;
		curCapResolution.subType = pmtConfig->subtype;
	}

	int iCount = 0, iSize = 0;

	for (int iFormat = 0; iFormat < iCount; iFormat++)
	{
			hr = g_DShowCaptureGraph.GetStreamCaps(STREAM_CAPTURE,iFormat, &pmtConfig, (BYTE*)&scc);
			if (SUCCEEDED(hr))
			{
				// Examine the format. 			 
			    // since our camera don't support cropping, we use the original output
				pVih = (VIDEOINFOHEADER*)pmtConfig->pbFormat;	
				RETAILMSG(1,(TEXT("pVih->bmiHeader.biWidth = %lu***********\r\n"),pVih->bmiHeader.biWidth));
				if (pVih->bmiHeader.biWidth == curCapResolution.width && pVih->bmiHeader.biHeight == curCapResolution.height)
				{
					g_CaptureResolutionIndex = iFormat;													
				}
			}

	}
	return hr;
}
//
//  FUNCTION: GetVideoProfile
//
//  PURPOSE: Get current Video Profile
//
//  COMMENTS:
//
HRESULT GetVideoProfile(int nStream,UINT8 nCurrentRes)
{
	HRESULT hr;
	RETAILMSG(1,(TEXT("GetVideoProfile nCurrentRes = %d \r\n"),nCurrentRes));
	VIDEO_STREAM_CONFIG_CAPS scc;
	AM_MEDIA_TYPE *pmtConfig;
	VIDEOINFOHEADER *pVih;
	hr = g_DShowCaptureGraph.GetStreamCaps(nStream,nCurrentRes, &pmtConfig, (BYTE*)&scc);
	if (SUCCEEDED(hr))
	{
		// Examine the format. 			 
	    // since our camera don't support cropping, we use the original output
		pVih = (VIDEOINFOHEADER*)pmtConfig->pbFormat;	
		RETAILMSG(1,(TEXT("pVih->bmiHeader.biWidth = %lu***********\r\n"),pVih->bmiHeader.biWidth));
		
			//RETAILMSG(1,(TEXT("GetStreamCaps = %lu\r\n"),pVih->bmiHeader.biWidth));
			if(nStream == STREAM_CAPTURE)
			{
				g_DShowCaptureGraph.GetStreamCaps(nStream,nCurrentRes,&g_CurrentVideoProfile, (BYTE*)&scc);
			}
			if(nStream == STREAM_STILL)
			{
				g_DShowCaptureGraph.GetStreamCaps(nStream,nCurrentRes,&g_CurrentStillProfile, (BYTE*)&scc);
			}
											
		
	}
	
	RETAILMSG(1,(TEXT("ChangeCurrentResolution DOne\r\n")));
	return hr;
}


