DirectShow Camera Demo Application for Windows CE

1.If you get this "lstrlenW is not a member of ATL" build error, Please install http://www.microsoft.com/en-us/download/confirmation.aspx?id=27729 and add below path in "Additional Include Directoiries"
C:\Program Files (x86)\Microsoft Visual Studio 9.0\VC\ce7\atlmfc\include

2. Used VS2013(vcxproj) to build WEC2013 Application. Used VS2008(vcproj) to build CE6,CE7 Application

