//======================================================================
// Header file
//
// Copyright (C) 2005 Douglas Boling
//======================================================================


#ifndef __CAMERACODELIB_H_
#define __CAMERACODELIB_H_


#ifdef DEBUG
// Debug zone constants.  The first 4 need to be standard across
// all native code that includes these routines.  In addition
// the CameraCode reserves the top 4 zones for itself.
#define ZONE_ERROR      DEBUGZONE(0)
#define ZONE_WARNING    DEBUGZONE(1)
#define ZONE_FUNC       DEBUGZONE(2)
#define ZONE_INIT       DEBUGZONE(3)

#define ZONE_TIMING     DEBUGZONE(12)
#define ZONE_DECODING   DEBUGZONE(13)
#define ZONE_CAMCODE3   DEBUGZONE(14)
#define ZONE_CAMCODE4   DEBUGZONE(15)

#endif //DEBUG

#ifndef GETZONESONLY

// Call first before anything else
DWORD InitCamera (LPTSTR pszCamName);

// Call after last call to camera library
int ShutdownCamera (DWORD dwContext);

// Initialize the image converters
HRESULT InitConverters (LPCWSTR pszExt);

// Free the converter interfaces
HRESULT FreeConverters (void);

// Returns the video formats supported on the device
int GetVideoFormats (DWORD dwContext, PFORMATPROPS pFormats, int *pnCnt, DWORD dwFormat);

// Returns the still image formats supported on the device
int GetStillFormats (DWORD dwContext, PFORMATPROPS pFormats, int *pnCount, DWORD dwFormat);

// Returns a string labeling a given feature ID
LPCTSTR GetFeatureText (DWORD dwFeatureID);

// Queries a feature value
int GetFeatureSetting (DWORD dwContext, DWORD dwFeature, DWORD *pdwVal);

// Sets a feature value
int SetFeatureSetting (DWORD dwContext, DWORD dwFeature, DWORD dwVal);

// Returns the list of features supported by the phone
int GetFeatureList (DWORD dwContext, PFEATUREPROPS pFeatures, DWORD *pdwSize);

// Starts streaming and returns the first frame of video
int GetFirstStreamFrame (DWORD dwContext, WORD wFormat, WORD wFrame, DWORD dwInterval, 
						 PBYTE *ppFrame, DWORD *pdwFrameSize, DWORD dwTimeout);

// Returns the next frame of video.
int GetNextStreamFrame (DWORD dwContext, PBYTE *ppFrame, DWORD *pdwFrameSize, 
						DWORD dwFlags, DWORD dwTimeout);

int GetCameraID (DWORD dwContext,DWORD *pCameraID);

// Called to end streaming by getfirst/getnext calls
int StreamFrameClose (DWORD dwContext);

// Start streaming to an HDC
int StartStreaming (DWORD dwContext, HDC hdc, RECT *prect, WORD wFormat, WORD wFrame, DWORD dwInterval);

// Stop streaming
int StopStreaming (DWORD dwContext);

// Capture a still image from the cameras
int GetStillImage (DWORD dwContext, WORD wFormat, WORD wFrame, PFORMATPROPS pFmt, PBYTE *ppData, DWORD *pdwSize);

// Writes an MJPEG frame as a JPEG file
int WriteJPEG (LPTSTR lpszName, PBYTE pData, int nSize);

// Sets or clears the drawing flag.  (useful for testing)
int SetDrawState (DWORD dwContext, BOOL fDraw);

// Sets or clears the motion detect flag.
int SetMotionDetectState (DWORD dwContext, BOOL fDetectMotion);

#endif // GETZONESONLY

#endif // __CAMERACODELIB_H_
