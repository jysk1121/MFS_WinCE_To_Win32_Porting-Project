#include <windows.h>
#include "streamframe.h"

// Implement a FileStream that derives from IStream.
FrameStream::FrameStream(PBYTE pFrame, DWORD dwSize) 
{ 
        _refcount = 0; 
		_pFrameData = pFrame;
		_dwSize = dwSize;
		_dwOffset = 0;
//		_pStream = 0;

		InitializeCriticalSection (&_cs);

	    // Create the stream
//   HRESULT hr = CreateStreamOnHGlobal(_pFrameData, TRUE, &_pStream);

}

FrameStream::~FrameStream() 
{ 

//		_pStream->Release();

		DeleteCriticalSection (&_cs);
}

HRESULT FrameStream::QueryInterface(
    REFIID iid,         // Identifier of the requested interface.
    void ** ppvObject   // Receives an indirect pointer to the object.
    ) 
{ 
    if (iid == __uuidof(IUnknown)
        || iid == __uuidof(IStream)
        || iid == __uuidof(ISequentialStream))
    {
        *ppvObject = static_cast<IStream*>(this);
        AddRef();
        return S_OK;
    } else
        return E_NOINTERFACE; 
}

ULONG FrameStream::AddRef(void) 
{ 
    return (ULONG)InterlockedIncrement(&_refcount); 
}

ULONG FrameStream::Release(void) 
{
    ULONG res = (ULONG) InterlockedDecrement(&_refcount);
    if (res == 0) 
        delete this;
    return res;
}

// ISequentialStream Interface
HRESULT FrameStream::Read(void* pv, ULONG cb, ULONG*   pcbRead)
{
//		return _pStream->Read (pv, cb, pcbRead);

	EnterCriticalSection (&_cs);

	// Limit check
	if ((_dwOffset + cb) > _dwSize)
		cb = _dwSize - _dwOffset;

	memcpy (pv, _pFrameData + _dwOffset, cb);
	_dwOffset += cb;
	*pcbRead = cb;

	LeaveCriticalSection (&_cs);
	return S_OK;
}


HRESULT FrameStream::
    Seek(LARGE_INTEGER liDistanceToMove, DWORD dwOrigin, ULARGE_INTEGER* lpNewFilePointer)                
{ 

//		return _pStream->Seek (liDistanceToMove, dwOrigin, lpNewFilePointer);

	HRESULT hr = S_OK;
	DWORD dwMove = (DWORD)liDistanceToMove.QuadPart;
    // Check to see if the origin is valid.

	EnterCriticalSection (&_cs);
    switch(dwOrigin)
    {
    case STREAM_SEEK_SET:
		if (dwMove > _dwSize)
			dwMove = _dwSize;

		_dwOffset = dwMove;
        break;
    case STREAM_SEEK_CUR:
		if ((_dwOffset + dwMove) > _dwSize)
			dwMove = _dwSize - _dwOffset;

		_dwOffset += dwMove;
        break;
    case STREAM_SEEK_END:
		if (dwMove > _dwSize)
			_dwOffset = 0;
		else
			_dwOffset = _dwSize - dwMove;
        break;
    default:   
        hr = STG_E_INVALIDFUNCTION;
        break;
    }
	LeaveCriticalSection (&_cs);
    return hr;
}

HRESULT FrameStream::Stat(STATSTG* pStatstg, DWORD grfStatFlag) 
{
//		return _pStream->Stat (pStatstg, grfStatFlag);

	pStatstg->cbSize.QuadPart = _dwSize;
    return S_OK;
}
