// Implement a FileStream that derives from IStream.
class FrameStream : public IStream
{
public:
    FrameStream(PBYTE pFrame, DWORD dwSize);
	~FrameStream(); 
    HRESULT STDMETHODCALLTYPE QueryInterface(
        REFIID iid,         // Identifier of the requested interface.
        void ** ppvObject   // Receives an indirect pointer to the object.
        );
    ULONG STDMETHODCALLTYPE AddRef(void);
    ULONG STDMETHODCALLTYPE Release(void);
    // ISequentialStream Interface
public:
    HRESULT STDMETHODCALLTYPE Read(void* pv, ULONG cb, ULONG*   pcbRead);
    HRESULT STDMETHODCALLTYPE Write(void const* pv, ULONG cb,   ULONG* pcbWritten)
    { 
        return E_NOTIMPL;   
    }

    // IStream Interface
public:
    HRESULT STDMETHODCALLTYPE SetSize(ULARGE_INTEGER)
    { 
        return E_NOTIMPL;   
    }
    HRESULT STDMETHODCALLTYPE 
        CopyTo(IStream*, ULARGE_INTEGER, ULARGE_INTEGER*, ULARGE_INTEGER*) 
    { 
        return E_NOTIMPL;   
    }
    HRESULT STDMETHODCALLTYPE Commit(DWORD)                                      
    { 
        return E_NOTIMPL;   
    }
    HRESULT STDMETHODCALLTYPE Revert(void)                                       
    { 
        return E_NOTIMPL;   
    }
    HRESULT STDMETHODCALLTYPE LockRegion(ULARGE_INTEGER, ULARGE_INTEGER, DWORD)              
    { 
        return E_NOTIMPL;   
    }
    HRESULT STDMETHODCALLTYPE UnlockRegion(ULARGE_INTEGER, ULARGE_INTEGER, DWORD)            
    { 
        return E_NOTIMPL;   
    }
    HRESULT STDMETHODCALLTYPE Clone(IStream **)                                  
    { 
        return E_NOTIMPL;   
    }

    HRESULT STDMETHODCALLTYPE 
        Seek(LARGE_INTEGER liDistanceToMove, DWORD dwOrigin, ULARGE_INTEGER* lpNewFilePointer);
    HRESULT STDMETHODCALLTYPE Stat(STATSTG* pStatstg, DWORD grfStatFlag);
private:

    IStream *_pStream;
	DWORD _dwOffset;
	DWORD _dwSize;
	PBYTE _pFrameData;
    LONG _refcount;
	CRITICAL_SECTION _cs;
};

#if 0
class FrameStream : public IStream
{
public:
    FrameStream(PBYTE pFrame, DWORD dwSize);
	~FrameStream(); 
    HRESULT STDMETHODCALLTYPE QueryInterface(
        REFIID iid,         // Identifier of the requested interface.
        void ** ppvObject   // Receives an indirect pointer to the object.
        );
    ULONG STDMETHODCALLTYPE AddRef(void);
    ULONG STDMETHODCALLTYPE Release(void);
    // ISequentialStream Interface
public:
    HRESULT STDMETHODCALLTYPE Read(void* pv, ULONG cb, ULONG*   pcbRead);
    HRESULT STDMETHODCALLTYPE Write(void const* pv, ULONG cb,   ULONG* pcbWritten)
    { 
        return E_NOTIMPL;   
    }

    // IStream Interface
public:
    HRESULT STDMETHODCALLTYPE SetSize(ULARGE_INTEGER)
    { 
        return E_NOTIMPL;   
    }
    HRESULT STDMETHODCALLTYPE 
        CopyTo(IStream*, ULARGE_INTEGER, ULARGE_INTEGER*, ULARGE_INTEGER*) 
    { 
        return E_NOTIMPL;   
    }
    HRESULT STDMETHODCALLTYPE Commit(DWORD)                                      
    { 
        return E_NOTIMPL;   
    }
    HRESULT STDMETHODCALLTYPE Revert(void)                                       
    { 
        return E_NOTIMPL;   
    }
    HRESULT STDMETHODCALLTYPE LockRegion(ULARGE_INTEGER, ULARGE_INTEGER, DWORD)              
    { 
        return E_NOTIMPL;   
    }
    HRESULT STDMETHODCALLTYPE UnlockRegion(ULARGE_INTEGER, ULARGE_INTEGER, DWORD)            
    { 
        return E_NOTIMPL;   
    }
    HRESULT STDMETHODCALLTYPE Clone(IStream **)                                  
    { 
        return E_NOTIMPL;   
    }

    HRESULT STDMETHODCALLTYPE 
        Seek(LARGE_INTEGER liDistanceToMove, DWORD dwOrigin, ULARGE_INTEGER* lpNewFilePointer);
    HRESULT STDMETHODCALLTYPE Stat(STATSTG* pStatstg, DWORD grfStatFlag);
private:

    IStream *_pStream;
	DWORD _dwOffset;
	DWORD _dwSize;
	PBYTE _pFrameData;
    LONG _refcount;
	CRITICAL_SECTION _cs;
};

#endif