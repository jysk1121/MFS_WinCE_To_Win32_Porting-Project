//======================================================================
// Header for conversion library that uses the Imaging component
// of Windows CE 5 and later.
//

// Call to initialize the library
HRESULT InitDisplayFrame (LPCWSTR pszExt);

// Call to convert MJPEG frame and write to a Device Context
HRESULT DisplayFrame (PBYTE pData, DWORD dwPreBuff, DWORD dwSize, HDC hdc, RECT *pRect);

typedef struct {
	int nHeight;
	int nWidth;
	int PixelFormat;
} BMPFMT, *PBMPFMT;

#if (_WIN32_WCE <= 0x700)
HRESULT DisplayBitmap (IBitmapImage *pBitmapImage, HDC hdc, RECT *pRect);

// Convert an MJPEG frame to an IBitmapImage object.
HRESULT GetBitMapImage (PBYTE pData, DWORD dwPreBuff, DWORD dwSize, 
						IBitmapImage **ppBitmapImage, PBMPFMT pInfo);

BOOL IsMotionDetected (IBitmapImage* pBitmapImage, IBitmapImage* pBitmapImageOld, PBMPFMT pInfo,
					   DWORD dwSenstivity);
#else
HRESULT DisplayBitmap(IWICBitmapSource *pBitmapImage, HDC hdc, RECT *pRect);

// Convert an MJPEG frame to an IBitmapImage object.
HRESULT GetBitMapImage (PBYTE pData, DWORD dwPreBuff, DWORD dwSize, 
	IWICBitmapSource **ppBitmapImage,PBMPFMT pInfo);

BOOL IsMotionDetected(IWICBitmapSource* pBitmapImage, IWICBitmapSource* pBitmapImageOld, PBMPFMT pInfo,
					   DWORD dwSenstivity);
#endif					   
					   




// Call to free the library
HRESULT ReleaseDisplayFrame ();
