//======================================================================
// Header file
//
// Copyright (C) 2005 Douglas Boling
//======================================================================

//#ifndef __CAMTEST2_H__
//#define __CAMTEST2_H__

#ifndef RES_INC_ONLY
// Returns number of elements
#define dim(x) (sizeof(x) / sizeof(x[0])) 

//
// Debug zone support
//
// Used as a prefix string for all debug zone messages.
#define DTAG        TEXT ("CamTest: ")

// Debug zone constants
#define ZONE_ERROR      DEBUGZONE(0)
#define ZONE_WARNING    DEBUGZONE(1)
#define ZONE_FUNC       DEBUGZONE(2)
#define ZONE_INIT       DEBUGZONE(3)


//----------------------------------------------------------------------
// Used for cross compile between Std. Win32 and CE
//
#ifdef _WIN32_WCE                     // If compiling for CE

#define LPCMDLINE LPWSTR
#define USECMDBAR  

#else                                 // compiling for NT

#define LPCMDLINE LPSTR
#define CommandBar_Height(a) 0
#ifdef UNICODE
#define _vstprintf vswprintf
#else
#define _vstprintf vsprintf
#endif //UNICODE

#endif //_WIN32_WCE_

//----------------------------------------------------------------------
// Generic defines and data types
//
struct decodeUINT {                            // structure associates
    UINT Code;                                 // messages 
                                               // with a function 
    LRESULT (*Fxn)(HWND, UINT, WPARAM, LPARAM);
}; 
struct decodeCMD {                             // structure associates
    UINT Code;                                 // menu IDs with a 
    LRESULT (*Fxn)(HWND, WORD, HWND, WORD);    // function
};

typedef struct
{
	WORD wFormat;
	WORD wFrame;
	TCHAR szFileName[MAX_PATH];
} STILLCAPDLGSTRUCT, *PSTILLCAPDLGSTRUCT;

//----------------------------------------------------------------------
// Function prototypes
//
int InitApp (HINSTANCE);
HWND InitInstance (HINSTANCE, LPCMDLINE, int);
int TermInstance (HINSTANCE, int);

// Window procedures
LRESULT CALLBACK MainWndProc(HWND, UINT, WPARAM, LPARAM);

BOOL CALLBACK SettingsDlgProc (HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK StillCapDlgProc (HWND, UINT, WPARAM, LPARAM);

// Message handlers
LRESULT DoCreateMain (HWND, UINT, WPARAM, LPARAM);
LRESULT DoDrawImageMain (HWND, UINT, WPARAM, LPARAM);
LRESULT DoSizeMain (HWND, UINT, WPARAM, LPARAM);
LRESULT DoInitMenuMain (HWND, UINT, WPARAM, LPARAM);
LRESULT DoPaintMain (HWND, UINT, WPARAM, LPARAM);
LRESULT DoCommandMain (HWND, UINT, WPARAM, LPARAM);
LRESULT DoDestroyMain (HWND, UINT, WPARAM, LPARAM);

// Command functions
LPARAM DoMainCommandExit (HWND, WORD, HWND, WORD);
LPARAM DoMainCommandAbout (HWND, WORD, HWND, WORD);
LPARAM DoCommandImageSize (HWND, WORD, HWND, WORD);
LPARAM DoCommandImageRate (HWND, WORD, HWND, WORD);
LPARAM DoCommandStartStream (HWND, WORD, HWND, WORD);
LPARAM DoCommandStopStream (HWND, WORD, HWND, WORD);
LPARAM DoCommandSetSettings (HWND, WORD, HWND, WORD);
LPARAM DoCommandGetStillImage (HWND, WORD, HWND, WORD);
LPARAM DoCommandStopDrawing (HWND, WORD, HWND, WORD);
LPARAM DoCommandDetectMotion (HWND, WORD, HWND, WORD);

#endif //#ifndef RES_INC_ONLY

//----------------------------------------------------------------------
// Generic defines used by application
#define  IDC_CMDBAR     1                      // Command bar ID
#define  IDC_FMTLIST    2                      // Format listbox
#define  IDC_FRMLIST    3                      // Frame size listbox
#define  IDC_INTERVAL   4                      // Frame Interval listbox

// Moved these here from resource.h for better control of the IDs
#define ID_IMAGESIZE                    150
//#define ID_CAMERA_SETTINGS              151

//#define ID_CAMERA_IMAGESIZE_1           200
#define ID_CAMERA_IMAGESIZE_2           201
#define ID_CAMERA_IMAGESIZE_3           202
#define ID_CAMERA_IMAGESIZE_4           203
#define ID_CAMERA_IMAGESIZE_5           204
#define ID_CAMERA_IMAGESIZE_6           205
#define ID_CAMERA_IMAGESIZE_7           206
#define ID_CAMERA_IMAGESIZE_8           207
#define ID_CAMERA_IMAGESIZE_9           208

//#define ID_CAMERA_IMAGERATE_1           401
#define ID_CAMERA_IMAGERATE_2           402
#define ID_CAMERA_IMAGERATE_3           403
#define ID_CAMERA_IMAGERATE_4           404
#define ID_CAMERA_IMAGERATE_5           405
#define ID_CAMERA_IMAGERATE_6           406
#define ID_CAMERA_IMAGERATE_7           407
#define ID_CAMERA_IMAGERATE_8           408
#define ID_CAMERA_IMAGERATE_9           409


//#endif //__CAMTEST2_H__