//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CamTest.rc
//
#define IDR_MENU1                       101
#define IDD_PROPPAGE_LARGE              102
#define IDC_SETTINGS                    102
#define IDD_STILLCAPDLG                 103
#define ID_CAMERA_IMAGESIZE_1           200
#define ID_CAMERA_IMAGERATE_1           400
#define IDC_SETTINGSLIST                1000
#define IDC_PROPSETTING                 1002
#define IDC_MAXTEXT                     1003
#define IDC_MINTEXT                     1004
#define IDC_CURTEXT                     1005
#define IDC_ONOFFCHECK                  1006
#define IDC_FORMATLIST                  1007
#define IDC_FILENAME                    1008
#define ID_FILE_EXIT                    40001
#define ID_CAMERA_STARTSTREAM           40002
#define ID_CAMERA_STOPSTREAM            40003
#define ID_CAMERA_GETSTILLIMAGE         40004
#define ID_CAMERA_SETTINGS              40005
#define ID_HELP_ABOUT                   40022
#define ID_CAMERA_STOPDRAWING           40023
#define ID_CAMERA_DETECTMOTION          40024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40025
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
