//======================================================================
// StillCapDlg - Dialog proc code for still capture dlg box
//
// Copyright (C) 2005 Douglas Boling
//
//======================================================================
#include <windows.h>                 // For all that Windows stuff
#include <commctrl.h>                // Command bar includes
#include <winioctl.h>                // Needed for CTLCODE macro

#include "CamTest.h"                // Program specific stuff
#include <webcamsdk.h>				// WebCam IOCTLs and structures

#include "..\CameraCode\CameraCode.h"     // Camera routines
#include "resource.h"

//int SetControlVals (HWND hWnd, PFEATUREPROPS pProps);

#define MAXSTILLFORMATS  15

extern DWORD dwContext;

TCHAR szStillFileName[MAX_PATH] = TEXT("sample.jpg");
int nStillFmtCnt = MAXSTILLFORMATS;
FORMATPROPS StillFormats[MAXSTILLFORMATS];

//======================================================================
// Modeless Camera Settings Dialog proc
//
BOOL CALLBACK StillCapDlgProc (HWND hWnd, UINT wMsg, WPARAM wParam,
                               LPARAM lParam) {
	int i, rc;
	TCHAR sz[MAX_PATH];
	static PSTILLCAPDLGSTRUCT pStillCap;

    switch (wMsg) 
	{

	case WM_INITDIALOG:
		{
			if (lParam == 0)
				return TRUE;
			pStillCap = (PSTILLCAPDLGSTRUCT)lParam;

			// Get the list of still formats supported
			rc = GetStillFormats (dwContext, StillFormats, &nStillFmtCnt, pStillCap->wFormat);

			// Fill the list box with the supported formats
			for (i = 0; i < nStillFmtCnt; i++)
			{
				wsprintf (sz, TEXT("%d x %d"), StillFormats[i].dwWidth, StillFormats[i].dwHeight);
				SendDlgItemMessage (hWnd, IDC_FORMATLIST, LB_ADDSTRING, 0, (LPARAM)sz);
			}
			SendDlgItemMessage (hWnd, IDC_FORMATLIST, LB_SETCURSEL, 0, 0);

			// Set the default image file name
			SetDlgItemText (hWnd, IDC_FILENAME, szStillFileName);
		}
		break;

	case WM_COMMAND:
		{
			WORD idItem = (WORD) LOWORD (wParam);
			WORD wNotifyCode = (WORD) HIWORD (wParam);

			switch (idItem) 
			{
				case IDOK:
					// Get the file name
					GetDlgItemText (hWnd, IDC_FILENAME, szStillFileName, 
					                dim (szStillFileName));
					if (lstrlen (szStillFileName) == 0)
					{
						MessageBox (hWnd, TEXT("A file name is required."), 
						            TEXT("Error"), MB_OK);
						return TRUE;
					}
					lstrcpy (pStillCap->szFileName, szStillFileName);

					// Get the image size
					i = SendDlgItemMessage (hWnd, IDC_FORMATLIST, LB_GETCURSEL, 0, 0);
					if ((i >= 0) && (i < nStillFmtCnt))
					{
						pStillCap->wFormat = StillFormats[i].wFormatIndex;
						pStillCap->wFrame = StillFormats[i].wFrameIndex;
					}
					EndDialog (hWnd, 1);
					return TRUE;

				case IDCANCEL:
					EndDialog (hWnd, 0);
					return TRUE;
			}
		}
	    break;
    }
    return FALSE;
}
//----------------------------------------------------------------------
//SetControlVals - Helper function to set dlg box control values
//
int SetControlVals1 (HWND hWnd, PFEATUREPROPS pProps)
{
	int i, rc;
	TCHAR sz[256];
	DWORD dwVal;

	i = SendDlgItemMessage (hWnd, IDC_SETTINGSLIST, LB_GETCURSEL, 0, 0);
	if (i < pProps->nNumProps)
	{
		wsprintf (sz, TEXT("Minimum\r\n%d"), pProps->fpArray[i].nMin);
		SetDlgItemText (hWnd, IDC_MINTEXT, sz);
		wsprintf (sz, TEXT("Maximum\r\n%d"), pProps->fpArray[i].nMax);
		SetDlgItemText (hWnd, IDC_MAXTEXT, sz);

		// Set slider limits
		SendDlgItemMessage (hWnd, IDC_PROPSETTING, TBM_SETRANGEMIN, 
							0, pProps->fpArray[i].nMin);

		SendDlgItemMessage (hWnd, IDC_PROPSETTING, TBM_SETRANGEMAX, 
							TRUE, pProps->fpArray[i].nMax);

//		int ticks = pProps->fpArray[i].nMax - pProps->fpArray[i].nMin;
//		if (ticks > 16) 
//			ticks = 16;
//		SendDlgItemMessage (hWnd, IDC_PROPSETTING, TBM_SETTIC,
//							0, ticks);


		// Get the current value
		rc = GetFeatureSetting (dwContext, pProps->fpArray[i].dwFeatureID, &dwVal);
		if (rc == 0)
		{
			wsprintf (sz, TEXT("Currently\r\n%d"), dwVal);
			SetDlgItemText (hWnd, IDC_CURTEXT, sz);

			// Set slider position
			SendDlgItemMessage (hWnd, IDC_PROPSETTING, TBM_SETPOS, 
								TRUE, dwVal);
		}
		else
		{
			wsprintf (sz, TEXT("Err\r\n%d"), rc);
			SetDlgItemText (hWnd, IDC_CURTEXT, sz);
		}
	}
	return 0;
}