//======================================================================
// CamSettings - Dialog proc code for Camera settings modeless dlg box
//
// Copyright (C) 2005 Douglas Boling
//
//======================================================================
#include <windows.h>                 // For all that Windows stuff
#include <commctrl.h>                // Command bar includes
#include <winioctl.h>                // Needed for CTLCODE macro

#include "CamTest.h"                // Program specific stuff
#include <webcamsdk.h>				// WebCam IOCTLs and structures

#include "..\CameraCode\CameraCode.h"    // Camera routines
#include "resource.h"

int SetControlVals (HWND hWnd, PFEATUREPROPS pProps);

extern HWND g_hwndMlDlg;
extern DWORD dwContext;

//======================================================================
// Modeless Camera Settings Dialog proc
//
BOOL CALLBACK SettingsDlgProc (HWND hWnd, UINT wMsg, WPARAM wParam,
                               LPARAM lParam) {
	int i, rc;
	TCHAR sz[256];
	DWORD dwSize, dwVal;
	static PFEATUREPROPS pProps;
    switch (wMsg) 
	{

	case WM_INITDIALOG:
		{
			// Get the size of the returned data
			rc = GetFeatureList (dwContext, NULL, &dwSize);
			if (rc)
			{
				printf ("Error getting feature list size rc %d\r\n", rc);
				return TRUE;
			}
			// Allocate the buffer
			pProps = (PFEATUREPROPS) LocalAlloc (LPTR, dwSize);

			rc = GetFeatureList (dwContext, pProps, &dwSize);
			
			int i;
			for (i = 0; i < pProps->nNumProps; i++)
			{
//				wsprintf (sz, TEXT(" %02d %s"), pProps->fpArray[i].dwFeatureID, GetFeatureText (pProps->fpArray[i].dwFeatureID));
//				SendDlgItemMessage (hWnd, IDC_SETTINGSLIST, LB_ADDSTRING, 0, (LPARAM)sz);
				SendDlgItemMessage (hWnd, IDC_SETTINGSLIST, LB_ADDSTRING, 0, 
				                    (LPARAM)GetFeatureText (pProps->fpArray[i].dwFeatureID));
			}
			SendDlgItemMessage (hWnd, IDC_SETTINGSLIST, LB_SETCURSEL, 0, 0);
			SetControlVals (hWnd, pProps);
		}
		break;

	case WM_COMMAND:
		{
			WORD idItem = (WORD) LOWORD (wParam);
			WORD wNotifyCode = (WORD) HIWORD (wParam);

			switch (idItem) 
			{
				case IDC_SETTINGSLIST:
					if (wNotifyCode == LBN_SELCHANGE)
					{
						SetControlVals (hWnd, pProps);
					}
					break;

				case IDC_PROPSETTING:
					break;
				case IDOK:
				case IDCANCEL:
					// Modeless dialog boxes can't use EndDialog.
					DestroyWindow (hWnd);
					return TRUE;
			}
		}
	    break;

	case WM_VSCROLL:
		{
			dwVal = SendDlgItemMessage (hWnd, IDC_PROPSETTING, TBM_GETPOS, 0, 0);

			// Get the selected feature
			i = SendDlgItemMessage (hWnd, IDC_SETTINGSLIST, LB_GETCURSEL, 0, 0);

			// Range check.
			if (i < pProps->nNumProps)
			{
				// Set the new value
				rc = SetFeatureSetting (dwContext, pProps->fpArray[i].dwFeatureID, dwVal);
				if (rc)
					printf ("Error calling SetFeatureSetting rc %d\r\n", rc);

				// Get back the new value
				rc = GetFeatureSetting (dwContext, pProps->fpArray[i].dwFeatureID, &dwVal);
				if (rc == 0)
				{
					wsprintf (sz, TEXT("Currently\r\n%d"), dwVal);
					SetDlgItemText (hWnd, IDC_CURTEXT, sz);

					// Set slider position
					SendDlgItemMessage (hWnd, IDC_PROPSETTING, TBM_SETPOS, 
								        0, dwVal);
				}
				else
				{
					wsprintf (sz, TEXT("Err\r\n%d"), rc);
					SetDlgItemText (hWnd, IDC_CURTEXT, sz);
				}
			}
		} 
	    break;

	case WM_DESTROY:
		g_hwndMlDlg = 0;  // 0 means dlg destroyed.
		break;
    }
    return FALSE;
}
//----------------------------------------------------------------------
//SetControlVals - Helper function to set dlg box control values
//
int SetControlVals (HWND hWnd, PFEATUREPROPS pProps)
{
	int index, rc;
	TCHAR sz[256];
	DWORD dwVal;

	index = SendDlgItemMessage (hWnd, IDC_SETTINGSLIST, LB_GETCURSEL, 0, 0);
	if (index < pProps->nNumProps)
	{
		if(pProps->fpArray[index].dwFlags & FLAG_FP_AUTO)
		{
			wsprintf (sz, TEXT("Auto\r\n"));
			SetDlgItemText (hWnd, IDC_MINTEXT, sz);
			SetDlgItemText (hWnd, IDC_MAXTEXT, sz);
		}
		else if (pProps->fpArray[index].dwFlags & FLAG_FP_ERROR)
		{
			wsprintf (sz, TEXT("Error\r\n%d"), pProps->fpArray[index].nMin);
			SetDlgItemText (hWnd, IDC_MINTEXT, sz);
			SetDlgItemText (hWnd, IDC_MAXTEXT, sz);
		}
		else
		{
			wsprintf (sz, TEXT("Minimum\r\n%d"), pProps->fpArray[index].nMin);
			SetDlgItemText (hWnd, IDC_MINTEXT, sz);
			wsprintf (sz, TEXT("Maximum\r\n%d"), pProps->fpArray[index].nMax);
			SetDlgItemText (hWnd, IDC_MAXTEXT, sz);
		}
		// Set slider limits
		SendDlgItemMessage (hWnd, IDC_PROPSETTING, TBM_SETRANGEMIN, 
							0, pProps->fpArray[index].nMin);

		SendDlgItemMessage (hWnd, IDC_PROPSETTING, TBM_SETRANGEMAX, 
							TRUE, pProps->fpArray[index].nMax);

		// Compute the spread and set tick frequency
		int nTick = pProps->fpArray[index].nMax - pProps->fpArray[index].nMin;
		if (nTick > 2048) 
			nTick = 256;
		else if (nTick > 256)
			nTick = 16;
		else if (nTick > 16)
			nTick = 4;
		else 
			nTick = 1;
		SendDlgItemMessage (hWnd, IDC_PROPSETTING, TBM_SETTICFREQ, nTick, 0);

		// Get the current value
		rc = GetFeatureSetting (dwContext, pProps->fpArray[index].dwFeatureID, &dwVal);
		if (rc == 0)
		{
			wsprintf (sz, TEXT("Currently\r\n%d"), dwVal);
			SetDlgItemText (hWnd, IDC_CURTEXT, sz);

			// Set slider position
			SendDlgItemMessage (hWnd, IDC_PROPSETTING, TBM_SETPOS, 
								TRUE, dwVal);
		}
		else
		{
			wsprintf (sz, TEXT("Err\r\n%d"), rc);
			SetDlgItemText (hWnd, IDC_CURTEXT, sz);
		}
	}
	return 0;
}